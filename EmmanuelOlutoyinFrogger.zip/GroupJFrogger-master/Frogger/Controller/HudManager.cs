﻿using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Frogger.Settings;

namespace Frogger.Controller
{
    /// <summary>
    /// Manages the HUD elements in the game, including the display of lives, score, timer, and game name.
    /// </summary>
    public class HudManager
    {
        #region Data members

        private TextBlock livesText;
        private TextBlock scoreText;
        private TextBlock timerText;
        private TextBlock gameNameText;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="HudManager"/> class.
        /// </summary>
        /// <param name="gameManager">The game manager.</param>
        public HudManager(GameManager gameManager)
        {
            gameManager.ScoreChanged += this.UpdateScore;
            gameManager.LivesChanged += this.UpdateLives;
            gameManager.LifeTimerChanged += this.updateTimer;
        }

        #endregion

        #region Methods

        private void updateTimer(object sender, int secondsLeft)
        {
            this.timerText.Text = $"Timer: {secondsLeft}";
        }

        /// <summary>
        /// Initializes the hud.
        /// </summary>
        /// <param name="gameCanvas">The game canvas.</param>
        /// <param name="gameManager">The game manager.</param>
        public void InitializeHud(Canvas gameCanvas, GameManager gameManager)
        {
            var highShoulderYLocation = (double)Application.Current.Resources["HighShoulderYLocation"];
            var lowShoulderYLocation = (double)Application.Current.Resources["LowShoulderYLocation"];
            var canvasWidth = gameCanvas.Width;

            this.livesText = new TextBlock
            {
                FontSize = 24, Foreground = new SolidColorBrush(Colors.White),
                Text = "Lives: " + GameSettings.StartingLives
            };
            Canvas.SetLeft(this.livesText, 10);
            Canvas.SetTop(this.livesText, highShoulderYLocation - 40);
            gameCanvas.Children.Add(this.livesText);

            this.scoreText = new TextBlock
                { FontSize = 24, Foreground = new SolidColorBrush(Colors.White), Text = "Score: 0" };
            Canvas.SetLeft(this.scoreText,
                canvasWidth - 150);
            Canvas.SetTop(this.scoreText, lowShoulderYLocation);
            gameCanvas.Children.Add(this.scoreText);

            this.timerText = new TextBlock
            {
                FontSize = 24, Foreground = new SolidColorBrush(Colors.White),
                Text = "Timer: " + GameSettings.OfSecondsForTimer
            };
            Canvas.SetLeft(this.timerText,
                canvasWidth - 635);
            Canvas.SetTop(this.timerText, lowShoulderYLocation);
            gameCanvas.Children.Add(this.timerText);

            this.gameNameText = new TextBlock
                { FontSize = 24, Foreground = new SolidColorBrush(Colors.White), Text = "Frogger" };
            Canvas.SetLeft(this.gameNameText,
                canvasWidth / 2 - 50);
            Canvas.SetTop(this.gameNameText, highShoulderYLocation - 40);
            gameCanvas.Children.Add(this.gameNameText);
        }

        /// <summary>
        /// Updates the lives on the HUD.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="lives">The lives.</param>
        public void UpdateLives(object sender, int lives)
        {
            this.livesText.Text = $"Lives: {lives}";
        }

        /// <summary>
        /// Updates the score on the HUD.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="score">The score.</param>
        public void UpdateScore(object sender, int score)
        {
            this.scoreText.Text = $"Score: {score}";
        }

        #endregion
    }
}