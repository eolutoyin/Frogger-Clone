﻿using Frogger.ViewModel;

namespace Frogger.Controller
{
    /// <summary>
    /// Manages the display and interaction of the high score board within the game
    /// </summary>
    public class HighScoreBoardManager
    {
        #region Data members

        /// <summary>
        /// The high score board view model
        /// </summary>
        private readonly HighScoreBoardViewModel highScoreBoardViewModel;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="HighScoreBoardManager"/> class.
        /// </summary>
        /// <param name="viewModel">The view model.</param>
        public HighScoreBoardManager(HighScoreBoardViewModel viewModel)
        {
            this.highScoreBoardViewModel = viewModel;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Shows the high score board.
        /// </summary>
        /// <param name="score">The score.</param>
        /// <param name="level">The level.</param>
        public void ShowHighScoreBoard(int score, string level)
        {
            this.highScoreBoardViewModel.UpdateCurrentScoreAndLevel(score, level);
            this.highScoreBoardViewModel.ShowHighScoreBoard();
        }


        #endregion
    }
}