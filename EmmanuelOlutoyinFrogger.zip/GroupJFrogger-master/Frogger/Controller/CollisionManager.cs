﻿using System;
using Windows.UI.Xaml;
using Frogger.Model;
using Frogger.Model.GameObjects;
using Frogger.Model.Lanes;
using Frogger.Model.Levels;
using Frogger.Model.PowerUp;
using Frogger.Settings;
using Frogger.View.Sprites;

namespace Frogger.Controller
{
    /// <summary>
    /// Manages and detects collisions between various game objects in the game environment.
    /// </summary>
    public class CollisionManager
    {
        #region Data members

        private readonly GameObject player;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the lanes.
        /// </summary>
        /// <value>
        /// The lanes.
        /// </value>
        public Lane[] Lanes { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CollisionManager"/> class.
        /// </summary>
        /// <param name="player">The player.</param>
        /// <param name="lanes">The lanes.</param>
        public CollisionManager(GameObject player, Lane[] lanes)
        {
            this.player = player;
            this.Lanes = lanes;
            player.PositionChanged += this.handlePlayerPositionChanged;
            foreach (var lane in lanes)
            {
                foreach (var obstacle in lane.GetLaneObjects())
                {
                    obstacle.PositionChanged += this.handleObstaclePositionChanged;
                }
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Checks the collision.
        /// </summary>
        /// <param name="obj1">The obj1.</param>
        /// <param name="obj2">The obj2.</param>
        /// <returns></returns>
        public bool CheckCollision(GameObject obj1, GameObject obj2)
        {
            if (!obj1.IsActive || !obj2.IsActive)
            {
                return false;
            }

            return obj1.Bounds.Left < obj2.Bounds.Right && obj1.Bounds.Right > obj2.Bounds.Left &&
                   obj1.Bounds.Top < obj2.Bounds.Bottom && obj1.Bounds.Bottom > obj2.Bounds.Top;
        }

        /// <summary>
        /// Handles the player position changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArgs">The <see cref="PositionChangedEventArgs"/> instance containing the event data.</param>
        private void handlePlayerPositionChanged(object sender, PositionChangedEventArgs eventArgs)
        {
            var currentPlayerLane = this.getLaneInYPosition(eventArgs.Y);
            this.HandleCollisions(this.player, currentPlayerLane);
        }

        private Lane getLaneInYPosition(double eventArgsY)
        {
            foreach (var lane in this.Lanes)
            {
                if (Math.Abs(lane.UpperLeftYPosition - eventArgsY) < GameSettings.ToleranceForComparing)
                {
                    return lane;
                }
            }

            return null;
        }

        private void handleObstaclePositionChanged(object sender, PositionChangedEventArgs eventArgs)
        {
            var currentPlayerLane = this.getLaneInYPosition(this.player.Y);
            this.HandleCollisions(this.player, currentPlayerLane);
        }

        /// <summary>
        /// Handles the collisions.
        /// </summary>
        /// <param name="playerToCheck">The player to check.</param>
        /// <param name="laneToCheck">The lane to check.</param>
        /// <exception cref="System.ArgumentOutOfRangeException"></exception>
        public void HandleCollisions(GameObject playerToCheck, Lane laneToCheck)
        {
            if (laneToCheck == null)
            {
                return;
            }

            if (playerToCheck.IsActive == false)
            {
                return;
            }

            if (playerIsInNotInALane(playerToCheck))
            {
                return;
            }

            switch (laneToCheck.Lanetype)
            {
                case LaneType.Road:
                    this.PlayerNoLongerOnRideableObject?.Invoke();
                    this.checkCollisionWithObstacles(playerToCheck, laneToCheck);
                    break;
                case LaneType.Home:
                    this.PlayerNoLongerOnRideableObject?.Invoke();
                    this.checkCollisionWithHomes(playerToCheck, laneToCheck);
                    break;
                case LaneType.River:
                    this.checkCollisionWithRiverObjects(playerToCheck, laneToCheck);
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        private void checkCollisionWithRiverObjects(GameObject playerToCheck, Lane laneToCheck)
        {
            for (var i = 0; i < laneToCheck.GetLaneObjects().Count; i++)
            {
                var laneObject = laneToCheck.GetLaneObjects()[i];
                var laneObjectType = laneObject.LaneObjectType;
                if (!this.CheckCollision(playerToCheck, laneObject))
                {
                    continue;
                }

                if (laneObjectIsPowerUp(laneObjectType))
                {
                    this.CollisionWithPowerUpDetected?.Invoke((PowerUp)laneObject);
                    laneToCheck.RemoveLaneObject(laneObject);
                    i--;
                    continue;
                }

                if (laneObjectIsRideableObject(laneObjectType))
                {
                    this.CollisionWithRideableObjectDetected?.Invoke(laneObject.SpeedX, laneToCheck.Direction);
                    return;
                }
            }

            this.PlayerNoLongerOnRideableObject?.Invoke();
            this.CollisionWithObjectThatCanKill?.Invoke(laneToCheck.Lanetype);
        }

        private static bool laneObjectIsRideableObject(LaneObjectType laneObjectType)
        {
            return laneObjectType == LaneObjectType.Boat || laneObjectType == LaneObjectType.Log;
        }

        private static bool playerIsInNotInALane(GameObject playerToCheck)
        {
            var lowShoulderYLocation = (double)Application.Current.Resources["LowShoulderYLocation"];
            return Math.Abs(playerToCheck.Y - lowShoulderYLocation) < GameSettings.ToleranceForComparing;
        }

        private void checkCollisionWithObstacles(GameObject playerToCheck, Lane laneToCheck)
        {
            for (var i = 0; i < laneToCheck.GetLaneObjects().Count; i++)
            {
                var laneObject = laneToCheck.GetLaneObjects()[i];
                var laneObjectType = laneObject.LaneObjectType;
                if (!this.CheckCollision(playerToCheck, laneObject))
                {
                    continue;
                }

                if (laneObjectIsPowerUp(laneObjectType))
                {
                    this.CollisionWithPowerUpDetected?.Invoke((PowerUp)laneObject);
                    laneToCheck.RemoveLaneObject(laneObject);
                    i--;
                }
                else if (laneObjectIsObstacleObject(laneObjectType))
                {
                    this.CollisionWithObjectThatCanKill?.Invoke(laneToCheck.Lanetype);
                }
                else
                {
                    this.CollisionDetected?.Invoke();
                }
            }
        }

        private static bool laneObjectIsObstacleObject(LaneObjectType laneObjectType)
        {
            return laneObjectType == LaneObjectType.Truck || laneObjectType == LaneObjectType.Car ||
                   laneObjectType == LaneObjectType.SuperCar;
        }

        private static bool laneObjectIsPowerUp(LaneObjectType laneObjectType)
        {
            return laneObjectType == LaneObjectType.PowerUp;
        }

        private void checkCollisionWithHomes(GameObject playerToCheck, Lane laneToCheck)
        {
            var homes = laneToCheck.GetLaneObjects();
            foreach (var home in homes)
            {
                if (home.Sprite is FrogHomeOccupiedSprite)
                {
                    if (playerToCheck.IntersectsWith(home))
                    {
                        this.CollisionWithOccupiedHomeDetected?.Invoke();
                        return;
                    }
                }
                else
                {
                    if (playerToCheck.IntersectsWith(home))
                    {
                        this.CollisionWithUnoccupiedHomeDetected?.Invoke(home);
                        return;
                    }
                }
            }
            this.CollisionWithObjectThatCanKill?.Invoke(laneToCheck.Lanetype);
        }

        /// <summary>
        /// Occurs when [collision detected].
        /// </summary>
        public event Action CollisionDetected;
        /// <summary>
        /// Occurs when [collision with object that can kill].
        /// </summary>
        public event Action<LaneType> CollisionWithObjectThatCanKill;
        /// <summary>
        /// Occurs when [collision with occupied home detected].
        /// </summary>
        public event Action CollisionWithOccupiedHomeDetected;
        /// <summary>
        /// Occurs when [collision with unoccupied home detected].
        /// </summary>
        public event Action<GameObject> CollisionWithUnoccupiedHomeDetected;
        /// <summary>
        /// Occurs when [collision with rideable object detected].
        /// </summary>
        public event Action<double, Direction> CollisionWithRideableObjectDetected;
        /// <summary>
        /// Occurs when [collision with power up detected].
        /// </summary>
        public event Action<PowerUp> CollisionWithPowerUpDetected;
        /// <summary>
        /// Occurs when [player no longer on rideable object].
        /// </summary>
        public event Action PlayerNoLongerOnRideableObject;

        #endregion
    }
}