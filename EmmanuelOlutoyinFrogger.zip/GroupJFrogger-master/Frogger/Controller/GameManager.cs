﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Frogger.Model;
using Frogger.Model.Animation;
using Frogger.Model.GameObjects;
using Frogger.Model.Lanes;
using Frogger.Model.Levels;
using Frogger.Model.PowerUp;
using Frogger.Model.Sound;
using Frogger.Settings;
using Frogger.View.Sprites;
using Frogger.ViewModel;

namespace Frogger.Controller
{
    /// <summary>
    ///     Manages all aspects of the game play including the player,
    ///     the vehicles as well as lives and score.
    /// </summary>
    public class GameManager
    {
        #region Data members

        private const int BottomLaneOffset = 5;
        private readonly double backgroundHeight;
        private readonly double backgroundWidth;
        private PlayerManager playerManager;
        private PowerUpManager powerUpManager;
        private SoundManager soundManager;
        private Canvas gameCanvas;
        private TextBlock gameOverText;
        private readonly HighScoreBoardManager highScoreBoardManager;

        private Frog player;
        private LaneManager laneManager;
        private CollisionManager collisionManager;
        private AnimationManager animationManager;
        private LevelManager levelManager;
        private TimerManager timerManager;

        private int lives = GameSettings.StartingLives;
        private int score;
        private int unoccupiedHousesLeft = GameSettings.OfHomes;
        /// <summary>
        /// Gets or sets a value indicating whether this instance is game paused.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is game paused; otherwise, <c>false</c>.
        /// </value>
        public bool IsGamePaused { get; set; }


        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="GameManager" /> class.
        /// </summary>
        /// <param name="backgroundHeight">LaneHeight of the background.</param>
        /// <param name="backgroundWidth">LaneWidth of the background.</param>
        /// <param name="highScoreBoardViewModel"></param>
        /// <exception cref="ArgumentOutOfRangeException">
        ///     backgroundHeight &lt;= 0
        ///     or
        ///     backgroundWidth &lt;= 0
        /// </exception>
        public GameManager(double backgroundHeight, double backgroundWidth,
            HighScoreBoardViewModel highScoreBoardViewModel)
        {
            if (backgroundHeight <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(backgroundHeight));
            }

            if (backgroundWidth <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(backgroundWidth));
            }

            this.backgroundHeight = backgroundHeight;
            this.backgroundWidth = backgroundWidth;
            this.highScoreBoardManager = new HighScoreBoardManager(highScoreBoardViewModel);

            this.setupManagers();
            this.setupTimers();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Occurs when [score changed].
        /// </summary>
        public event EventHandler<int> ScoreChanged;
        /// <summary>
        /// Occurs when [lives changed].
        /// </summary>
        public event EventHandler<int> LivesChanged;
        /// <summary>
        /// Occurs when [life timer changed].
        /// </summary>
        public event EventHandler<int> LifeTimerChanged;

        private void setupManagers()
        {
            this.timerManager = new TimerManager();
            this.animationManager = new AnimationManager();
            this.playerManager = new PlayerManager(this.backgroundHeight, this.backgroundWidth);
            this.powerUpManager = new PowerUpManager(this.backgroundWidth);
            this.soundManager = new SoundManager();
            this.levelManager = new LevelManager();
            this.levelManager.LoadNextLevel();
            this.laneManager = new LaneManager(this.levelManager.CurrentLevel.LevelLanes);
        }

        private void setupTimers()
        {
            this.timerManager.GameTimerTick -= this.gameTimerOnTick;
            this.timerManager.PowerUpTimerTick -= this.OnPowerUpTimerTick;
            this.timerManager.LifeTimerTick -= this.LifeTimerOnTick;
            this.timerManager.LifeDurationElapsed -= this.lifeDurationElapsed;

            this.timerManager.GameTimerTick += this.gameTimerOnTick;
            this.timerManager.PowerUpTimerTick += this.OnPowerUpTimerTick;
            this.timerManager.LifeTimerTick += this.LifeTimerOnTick;
            this.timerManager.LifeDurationElapsed += this.lifeDurationElapsed;

            this.timerManager.StartGameTimer();
            this.timerManager.StartPowerUpTimer();
            this.timerManager.StartLifeTimer();
        }

        private void lifeDurationElapsed(object sender, TimerEventArgs e)
        {
            _ = this.handleLossOfLife();
        }

        private void OnPowerUpTimerTick(object sender, object e)
        {
            if (!this.powerUpManager.ActivePowerUps.Any(p =>
                    p.PowerUpType == PowerUpType.ExtraTime || p.PowerUpType == PowerUpType.ExtraLife))
            {
                this.generateAndPlacePowerUp();
            }
        }

        private void generateAndPlacePowerUp()
        {
            var roadLane = this.selectRoadLaneForPowerUp();
            if (roadLane != null)
            {
                var random = new Random();
                var chosenPowerUpType = random.Next(2) == 0 ? PowerUpType.ExtraTime : PowerUpType.ExtraLife;

                var powerUp = this.powerUpManager.GeneratePowerUp(chosenPowerUpType);
                this.powerUpManager.SetPowerUpPosition(powerUp, roadLane);
                this.powerUpManager.AddPowerUp(powerUp);
                roadLane.AddLaneObject(powerUp);
                this.gameCanvas.Children.Add(powerUp.Sprite);
                powerUp.Sprite.RenderAt(powerUp.X, powerUp.Y);
            }
        }

        private Lane selectRoadLaneForPowerUp()
        {
            var roadLanes = this.laneManager.Lanes.Where(lane => lane.Lanetype == LaneType.Road).ToList();
            if (roadLanes.Any())
            {
                var randomIndex = new Random().Next(roadLanes.Count);
                return roadLanes[randomIndex];
            }

            return null;
        }

        private void LifeTimerOnTick(object sender, TimerEventArgs eventArgs)
        {
            this.LifeTimerChanged?.Invoke(this, eventArgs.TimeLeft);
            if (eventArgs.TimeLeft == GameSettings.OfSecondsForTimer / 4)
            {
                this.soundManager.PlaySound(SoundType.TimerRunningOut);
            }
        }

        /// <summary>
        ///     Initializes the game working with appropriate classes to place frog
        ///     and vehicle on game screen.
        ///     Precondition: gameCanvasToInitalizeGameOn != null
        ///     Postcondition: Game is initialized and ready for play.
        /// </summary>
        /// <param name="gameCanvasToInitalizeGameOn">The game canvas.</param>
        /// <exception cref="ArgumentNullException">gameCanvasToInitalizeGameOn</exception>
        public void InitializeGame(Canvas gameCanvasToInitalizeGameOn)
        {
            if (gameCanvasToInitalizeGameOn == null)
            {
                throw new ArgumentNullException(nameof(gameCanvasToInitalizeGameOn));
            }

            this.playerManager.CreateAndPlacePlayer(gameCanvasToInitalizeGameOn);
            this.player = this.playerManager.Player;
            this.createAndPlaceVehicles(gameCanvasToInitalizeGameOn);
            this.gameCanvas = gameCanvasToInitalizeGameOn;
            this.collisionManager =
                new CollisionManager(this.player, this.levelManager.CurrentLevel.LevelLanes.ToArray());
            this.collisionManager.CollisionWithObjectThatCanKill += this.handleObjectThatCanKillCollision;
            this.collisionManager.CollisionWithOccupiedHomeDetected += this.OnCollisionWithOccupiedHomeDetected;
            this.collisionManager.CollisionWithUnoccupiedHomeDetected += this.OnCollisionWithUnoccupiedHomeDetected;
            this.collisionManager.CollisionWithPowerUpDetected += this.OnCollisionWithPowerUpDetected;
            this.collisionManager.CollisionWithRideableObjectDetected += this.OnCollisionWithRiverObjectDetected;
            this.collisionManager.PlayerNoLongerOnRideableObject += this.OnPlayerNoLongerOnRideableObject;
        }

        private void OnPlayerNoLongerOnRideableObject()
        {
            this.playerManager.PlayerIsOnRideableObject = false;
        }

        private void OnCollisionWithRiverObjectDetected(double objectSpeed, Direction direction)
        {
            this.playerManager.AdjustStatsThatPlayerIsOnRideableObject(objectSpeed, direction);
        }

        private void OnCollisionWithPowerUpDetected(PowerUp powerUp)
        {
            this.powerUpManager.HandlePowerUpCollision(powerUp, ref this.lives,
                newLives => this.LivesChanged?.Invoke(this, newLives),
                extraTime => this.timerManager.AddTimeToLifeTimer(extraTime)
            );

            if (this.gameCanvas.Children.Contains(powerUp.Sprite))
            {
                this.gameCanvas.Children.Remove(powerUp.Sprite);
            }

            this.soundManager.PlaySound(SoundType.PowerUpAcquired);
        }

        private void OnCollisionWithUnoccupiedHomeDetected(GameObject home)
        {
            this.playerManager.ResetPlayer();
            this.gameCanvas.Children.Remove(home.Sprite);
            home.Sprite = new FrogHomeOccupiedSprite();
            this.gameCanvas.Children.Add(home.Sprite);
            home.Sprite.RenderAt(home.X, home.Y);
            this.handlePlayerAtHouse();
        }

        private void handlePlayerAtHouse()
        {
            var score = this.score += this.timerManager.SecondsLeft * 100;
            this.ScoreChanged?.Invoke(this, score);
            this.unoccupiedHousesLeft--;
            this.checkForGameOver();
        }

        private void OnCollisionWithOccupiedHomeDetected()
        {
            this.playerManager.MovePlayer(Direction.Down);
            this.soundManager.PlaySound(SoundType.CollisionWithWall);
        }

        private void createAndPlaceVehicles(Panel gameCanvasToPlace)
        {
            foreach (var laneObject in this.laneManager.Lanes.Select(lane => lane.GetLaneObjects()).SelectMany(laneObjects => laneObjects))
            {
                gameCanvasToPlace.Children.Add(laneObject.Sprite);
                laneObject.Sprite.RenderAt(laneObject.X, laneObject.Y);
            }
        }


        private void setPlayerToCenterOfBottomShoulder()
        {
            this.player.X = this.backgroundWidth / 2 - this.player.Width / 2;
            this.player.Y = this.backgroundHeight - this.player.Height - BottomLaneOffset;
        }

        private void gameTimerOnTick(object sender, object eventArgs)
        {
            if (this.IsGamePaused)
            {
                return; 
            }
            this.laneManager.MoveObstacleInEachLane();
            this.UpdateObstaclePositionsOnCanvas();
            if (this.playerManager.PlayerIsOnRideableObject)
            {
                this.playerManager.RideRideableObject();
            }
        }

        private void checkForGameOver()
        {
            if (this.lives == GameSettings.OfLivesToLose)
            {
                this.handleGameOver();
            }
            else if (this.unoccupiedHousesLeft == GameSettings.OfHomesForLose)
            {
                this.setupNextLevel();
            }
        }

        private void setupNextLevel()
        {
            var nextLevelAvailable = this.levelManager.LoadNextLevel();
            if (nextLevelAvailable)
            {
                this.clearCurrentLevel();
                this.timerManager.StopAllTimers();

                this.laneManager = new LaneManager(this.levelManager.CurrentLevel.LevelLanes);
                this.collisionManager.Lanes = this.levelManager.CurrentLevel.LevelLanes.ToArray();
                this.createAndPlaceVehicles(this.gameCanvas);
                this.timerManager.StartAllTimers();
                this.unoccupiedHousesLeft = GameSettings.OfHomes;
                this.soundManager.PlaySound(SoundType.LevelCompleted);
            }
            else
            {
                this.handleGameOver();
            }
        }

        private void handleGameOver()
        {
            this.timerManager.StopAllTimers();
            this.displayGameOverMessage();
            this.soundManager.PlaySound(SoundType.GameOver);

            var levelCompleted = this.levelManager.CurrentLevelType.ToString();
            this.highScoreBoardManager.ShowHighScoreBoard(this.score, levelCompleted);
        }

        private void clearCurrentLevel()
        {
            this.clearCanvasOfLaneObjects();
            _ = this.resetCanvas();
        }

        private void clearCanvasOfLaneObjects()
        {
            foreach (var laneObject in this.laneManager.Lanes.Select(lane => lane.GetLaneObjects()).SelectMany(laneObjects => laneObjects))
            {
                this.gameCanvas.Children.Remove(laneObject.Sprite);
            }
        }

        private Task resetCanvas()
        {
            this.setPlayerToCenterOfBottomShoulder();
            this.laneManager.ResetLanes();
            this.laneManager.ResetObstacleSpeed();
            this.playerManager.StopPlayer = false;
            this.player.IsActive = true;
            return Task.CompletedTask;
        }
        
        private async Task playDeathAnimationAsync()
        {
            this.laneManager.StopObstacles();
            this.playerManager.StopPlayer = true;
            this.player.IsActive = false;
            await this.animationManager.StartAnimationAsync(this.playerManager.Player, this.gameCanvas,
                AnimationType.FrogDeath, this.playerManager.PlayerCurrentDirection);
        }

        ///<summary>
        /// Resets the game back to the original value
        ///</summary>
        public void ResetGame()
        {
            this.timerManager.StopAllTimers();
            this.resetGameStats();
            this.levelManager.CurrentLevelType = LevelType.Uninitialized;
            this.setupNextLevel();
        }

        private void resetGameStats()
        {
            this.lives = GameSettings.StartingLives;
            this.score = GameSettings.StartingScore;
            this.LivesChanged?.Invoke(this, this.lives);
            this.ScoreChanged?.Invoke(this, this.score);
        }

        private void displayGameOverMessage()
        {
            this.gameOverText = new TextBlock
            {
                Text = "Game Over",
                FontSize = 48,
                Foreground = new SolidColorBrush(Colors.White)
            };

            Canvas.SetLeft(this.gameOverText, this.backgroundWidth / 3);
            Canvas.SetTop(this.gameOverText, this.backgroundHeight / 2.5);

            this.gameCanvas.Children.Add(this.gameOverText);
        }

        /// <summary>
        ///     Moves the player to the left.
        ///     Precondition: none
        ///     Postcondition: player.BottomLeftXPosition = player.BottomLeftXPosition@prev - player.LaneWidth
        /// </summary>
        public void MovePlayer(Direction direction)
        {
            this.playerManager.MovePlayer(direction);
            _ = this.animationManager.StartAnimationAsync(this.playerManager.Player, this.gameCanvas,
                AnimationType.FrogMovement, direction);
        }

        private void UpdateObstaclePositionsOnCanvas()
        {
            foreach (var obstacle in this.laneManager.Lanes.Select(lane => lane.GetLaneObjects()).SelectMany(obstacles => obstacles))
            {
                obstacle.Sprite.RenderAt(obstacle.X, obstacle.Y);
            }
        }

        private async void handleObjectThatCanKillCollision(LaneType laneType)
        {
            this.playDeathSoundBasedOnLaneType(laneType);
            if (laneType != LaneType.Home)
            {
                await this.handleLossOfLife();
            }
        }

        private void playDeathSoundBasedOnLaneType(LaneType laneType)
        {
            switch (laneType)
            {
                case LaneType.Road:
                    this.soundManager.PlaySound(SoundType.DeathViaCollisionWithVehicle);
                    break;
                case LaneType.River:
                    this.soundManager.PlaySound(SoundType.DeathViaWater);
                    break;
                case LaneType.Home:
                    this.soundManager.PlaySound(SoundType.CollisionWithWall);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(laneType), laneType, null);
            }
        }

        private async Task handleLossOfLife()
        {
            this.timerManager.StopAllTimers();
            this.LivesChanged?.Invoke(this, --this.lives);
            this.LifeTimerChanged?.Invoke(this, this.timerManager.SecondsLeft);
            await this.playDeathAnimationAsync();
            _ = this.resetCanvas();
            this.timerManager.StartAllTimers();
            this.checkForGameOver();
        }

        #endregion
    }
}