﻿using System;
using Windows.UI.Xaml;
using Frogger.Settings;

namespace Frogger.Controller
{
    /// <summary>
    /// Manages timers for the game, including the game timer, life timer, and power-up timer.
    /// </summary>
    public class TimerManager
    {
        #region Properties

        /// <summary>
        /// Gets the game timer.
        /// </summary>
        /// <value>
        /// The game timer.
        /// </value>
        public DispatcherTimer GameTimer { get; }
        /// <summary>
        /// Gets the life timer.
        /// </summary>
        /// <value>
        /// The life timer.
        /// </value>
        public DispatcherTimer LifeTimer { get; }
        /// <summary>
        /// Gets the power up timer.
        /// </summary>
        /// <value>
        /// The power up timer.
        /// </value>
        public DispatcherTimer PowerUpTimer { get; }
        /// <summary>
        /// Gets the seconds left.
        /// </summary>
        /// <value>
        /// The seconds left.
        /// </value>
        public int SecondsLeft { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TimerManager"/> class.
        /// </summary>
        public TimerManager()
        {
            this.GameTimer = createTimer(GameSettings.GameTimerInterval);
            this.LifeTimer = createTimer(GameSettings.LifeTimerInterval);
            this.PowerUpTimer = createTimer(GameSettings.PowerUpTimerInterval);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Occurs when [game timer tick].
        /// </summary>
        public event EventHandler GameTimerTick;
        /// <summary>
        /// Occurs when [life timer tick].
        /// </summary>
        public event EventHandler<TimerEventArgs> LifeTimerTick;
        /// <summary>
        /// Occurs when [power up timer tick].
        /// </summary>
        public event EventHandler PowerUpTimerTick;
        /// <summary>
        /// Occurs when [life duration elapsed].
        /// </summary>
        public event EventHandler<TimerEventArgs> LifeDurationElapsed;

        /// <summary>
        /// Creates the timer.
        /// </summary>
        /// <param name="interval">The interval.</param>
        /// <returns></returns>
        private static DispatcherTimer createTimer(TimeSpan interval)
        {
            var timer = new DispatcherTimer { Interval = interval };
            return timer;
        }

        /// <summary>
        /// Starts the game timer.
        /// </summary>
        public void StartGameTimer()
        {
            this.GameTimer.Tick -= this.GameTimer_Tick;
            this.GameTimer.Tick += this.GameTimer_Tick;
            this.GameTimer.Start();
        }

        /// <summary>
        /// Stops the game timer.
        /// </summary>
        public void StopGameTimer()
        {
            this.GameTimer.Stop();
            this.GameTimer.Tick -= this.GameTimer_Tick;
        }

        /// <summary>
        /// Starts the life timer.
        /// </summary>
        public void StartLifeTimer()
        {
            this.LifeTimer.Tick -= this.LifeTimer_Tick;
            this.SecondsLeft = GameSettings.OfSecondsForTimer;
            this.LifeTimer.Tick += this.LifeTimer_Tick;
            this.LifeTimer.Start();
        }

        /// <summary>
        /// Stops the life timer.
        /// </summary>
        public void StopLifeTimer()
        {
            this.LifeTimer.Stop();
            this.LifeTimer.Tick -= this.LifeTimer_Tick;
        }

        /// <summary>
        /// Starts the power up timer.
        /// </summary>
        public void StartPowerUpTimer()
        {
            this.PowerUpTimer.Tick += this.PowerUpTimer_Tick;
            this.PowerUpTimer.Start();
        }

        /// <summary>
        /// Stops the power up timer.
        /// </summary>
        public void StopPowerUpTimer()
        {
            this.PowerUpTimer.Stop();
            this.PowerUpTimer.Tick -= this.PowerUpTimer_Tick;
        }

        /// <summary>
        /// Powers up timer tick.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        private void PowerUpTimer_Tick(object sender, object e)
        {
            this.PowerUpTimerTick?.Invoke(sender, EventArgs.Empty);
        }

        /// <summary>
        /// Stops all timers.
        /// </summary>
        public void StopAllTimers()
        {
            this.StopGameTimer();
            this.StopLifeTimer();
            this.StopPowerUpTimer();
        }

        /// <summary>
        /// Starts all timers.
        /// </summary>
        public void StartAllTimers()
        {
            this.StartGameTimer();
            this.StartLifeTimer();
            this.StartPowerUpTimer();
        }

        private void LifeTimer_Tick(object sender, object e)
        {
            this.SecondsLeft -= GameSettings.LifeTimerInterval.Seconds;

            this.LifeTimerTick?.Invoke(sender, new TimerEventArgs(this.SecondsLeft));

            if (this.SecondsLeft == 0)
            {
                this.LifeDurationElapsed?.Invoke(this, new TimerEventArgs(this.SecondsLeft));
            }
        }

        private void GameTimer_Tick(object sender, object e)
        {
            this.GameTimerTick?.Invoke(sender, EventArgs.Empty);
        }

        /// <summary>
        /// Adds the time to life timer.
        /// </summary>
        /// <param name="additionalTime">The additional time.</param>
        public void AddTimeToLifeTimer(int additionalTime)
        {
            this.SecondsLeft += additionalTime;

            this.LifeTimerTick?.Invoke(this, new TimerEventArgs(this.SecondsLeft));
        }

        #endregion
    }
}