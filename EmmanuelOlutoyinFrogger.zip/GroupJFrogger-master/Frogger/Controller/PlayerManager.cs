﻿using System;
using Windows.Foundation;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Frogger.Model;
using Frogger.Model.GameObjects;

namespace Frogger.Controller
{
    /// <summary>
    /// Manages the player character in the game, handling its movement, position, rotation, and interaction with rideable objects. 
    /// </summary>
    public class PlayerManager
    {
        #region Data members

        private const int BottomLaneOffset = 5;
        private readonly double backgroundHeight;
        private readonly double backgroundWidth;
        private double speedOfObjectWhichPlayerIsOn;
        private Direction directionOfObjectWhichPlayerIsOn;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether [player is on rideable object].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [player is on rideable object]; otherwise, <c>false</c>.
        /// </value>
        public bool PlayerIsOnRideableObject { get; set; }

        /// <summary>
        /// Gets the player current direction.
        /// </summary>
        /// <value>
        /// The player current direction.
        /// </value>
        public Direction PlayerCurrentDirection { get; private set; } = Direction.Up;

        /// <summary>
        /// Gets or sets a value indicating whether [stop player].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [stop player]; otherwise, <c>false</c>.
        /// </value>
        public bool StopPlayer { get; set; }

        /// <summary>
        /// Gets the player.
        /// </summary>
        /// <value>
        /// The player.
        /// </value>
        public Frog Player { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PlayerManager"/> class.
        /// </summary>
        /// <param name="backgroundHeight">Height of the background.</param>
        /// <param name="backgroundWidth">Width of the background.</param>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// backgroundHeight
        /// or
        /// backgroundWidth
        /// </exception>
        public PlayerManager(double backgroundHeight, double backgroundWidth)
        {
            if (backgroundHeight <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(backgroundHeight));
            }

            if (backgroundWidth <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(backgroundWidth));
            }

            this.backgroundHeight = backgroundHeight;
            this.backgroundWidth = backgroundWidth;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Creates the and place player.
        /// </summary>
        /// <param name="gameCanvas">The game canvas.</param>
        /// <exception cref="System.ArgumentNullException">gameCanvas</exception>
        public void CreateAndPlacePlayer(Canvas gameCanvas)
        {
            if (gameCanvas == null)
            {
                throw new ArgumentNullException(nameof(gameCanvas));
            }

            this.StopPlayer = false;
            this.Player = new Frog();
            gameCanvas.Children.Add(this.Player.Sprite);
            this.setPlayerToCenterOfBottomShoulder();
        }

        /// <summary>
        /// Moves the player.
        /// </summary>
        /// <param name="direction">The direction.</param>
        public void MovePlayer(Direction direction)
        {
            if (this.StopPlayer)
            {
                return;
            }

            var originalX = this.Player.X;
            var originalY = this.Player.Y;

            this.PlayerCurrentDirection = direction;
            this.rotatePlayerBasedOnDirection(direction);

            this.Player.Move(direction);
            this.ensurePlayerIsInValidPosition(originalX, originalY);
        }

        /// <summary>
        /// Rides the rideable object.
        /// </summary>
        public void RideRideableObject()
        {
            var originalX = this.Player.X;
            var originalY = this.Player.Y;

            this.Player.Move(this.directionOfObjectWhichPlayerIsOn, this.speedOfObjectWhichPlayerIsOn, 0);
            this.ensurePlayerIsInValidPosition(originalX, originalY);
        }

        private void ensurePlayerIsInValidPosition(double originalX, double originalY)
        {
            if (!this.isValidPosition())
            {
                this.Player.X = originalX;
                this.Player.Y = originalY;
            }
        }

        private void rotatePlayerBasedOnDirection(Direction direction)
        {
            switch (direction)
            {
                case Direction.Up:
                    this.Player.Sprite.RenderTransform = new RotateTransform { Angle = 0 };
                    break;
                case Direction.Down:
                    this.Player.Sprite.RenderTransform = new RotateTransform { Angle = 180 };
                    break;
                case Direction.Left:
                    this.Player.Sprite.RenderTransform = new RotateTransform { Angle = 270 };
                    break;
                case Direction.Right:
                    this.Player.Sprite.RenderTransform = new RotateTransform { Angle = 90 };
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(direction), direction, null);
            }

            this.Player.Sprite.RenderTransformOrigin = new Point(0.5, 0.5);
        }

        /// <summary>
        /// Resets the player.
        /// </summary>
        public void ResetPlayer()
        {
            this.setPlayerToCenterOfBottomShoulder();
        }

        private void setPlayerToCenterOfBottomShoulder()
        {
            this.Player.Y = this.backgroundHeight - this.Player.Height - BottomLaneOffset;
            this.Player.X = this.backgroundWidth / 2 - this.Player.Width / 2;
        }

        private bool isValidPosition()
        {
            return !(this.Player.X < 0 || this.Player.X > this.backgroundWidth - this.Player.Width ||
                     this.Player.Y < 0 + this.Player.Height + BottomLaneOffset ||
                     this.Player.Y > this.backgroundHeight - this.Player.Height);
        }

        /// <summary>
        /// Adjusts the stats that player is on rideable object.
        /// </summary>
        /// <param name="speed">The speed.</param>
        /// <param name="objectDirection">The object direction.</param>
        public void AdjustStatsThatPlayerIsOnRideableObject(double speed, Direction objectDirection)
        {
            this.directionOfObjectWhichPlayerIsOn = objectDirection;
            this.speedOfObjectWhichPlayerIsOn = speed;
            this.PlayerIsOnRideableObject = true;
        }

        #endregion
    }
}