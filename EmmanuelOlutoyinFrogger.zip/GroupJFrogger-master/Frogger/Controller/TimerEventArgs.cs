﻿using System;

namespace Frogger.Controller
{
    /// <summary>
    /// Represents custom event arguments for a timer event.
    /// </summary>
    /// <seealso cref="System.EventArgs" />
    public class TimerEventArgs : EventArgs
    {
        #region Properties

        /// <summary>
        /// Gets the time left.
        /// </summary>
        /// <value>
        /// The time left.
        /// </value>
        public int TimeLeft { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TimerEventArgs"/> class.
        /// </summary>
        /// <param name="timeLeft">The time left.</param>
        public TimerEventArgs(int timeLeft)
        {
            this.TimeLeft = timeLeft;
        }

        #endregion
    }
}