﻿using System;
using System.Collections.Generic;
using Windows.UI.Xaml;
using Frogger.Model.Lanes;
using Frogger.Settings;

namespace Frogger.Controller
{
    /// <summary>
    /// Manages the lanes in the game, including the creation, reset, and movement of lane objects within each lane.
    /// </summary>
    public class LaneManager
    {

        #region Data members
        private DispatcherTimer laneTimer;

        #endregion

        #region Properties

        /// <summary>
        /// Gets the lanes.
        /// </summary>
        /// <value>
        /// The lanes.
        /// </value>
        public List<Lane> Lanes { get; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="LaneManager"/> class.
        /// </summary>
        /// <param name="lanes">The lanes.</param>
        public LaneManager(List<Lane> lanes)
        {
            this.Lanes = lanes;
            this.setupLaneTimer();
        }

        #endregion

        #region Methods

        private void setupLaneTimer()
        {
            this.laneTimer = new DispatcherTimer();
            this.laneTimer.Tick += this.laneTimerOnTick;
            this.laneTimer.Interval = new TimeSpan(0, 0, 0, GameSettings.OfSecondsBetweenAdditionalCars, 0);
            this.laneTimer.Start();
        }

        private void laneTimerOnTick(object sender, object e)
        {
            foreach (var lane in this.Lanes)
            {
                lane.RevealNextLaneObject();
            }
        }

        /// <summary>
        /// Resets the lanes.
        /// </summary>
        public void ResetLanes()
        {
            foreach (var lane in this.Lanes)
            {
                lane.ResetLane();
            }
        }

        /// <summary>
        /// Moves the obstacle in each lane.
        /// </summary>
        public void MoveObstacleInEachLane()
        {
            foreach (var lane in this.Lanes)
            {
                lane.MoveLaneObjects();
            }
        }

        /// <summary>
        /// Resets the obstacle speed.
        /// </summary>
        public void ResetObstacleSpeed()
        {
            this.Lanes.ForEach(lane => lane.ResetSpeed());
        }

        /// <summary>
        /// Stops the obstacles.
        /// </summary>
        public void StopObstacles()
        {
            this.Lanes.ForEach(lane => lane.StopLaneObjects());
        }

        #endregion
    }
}