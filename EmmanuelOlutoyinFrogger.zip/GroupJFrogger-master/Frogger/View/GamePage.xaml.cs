﻿using Windows.Foundation;
using Windows.System;
using Windows.UI.Core;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Frogger.Controller;
using Frogger.Model;
using Frogger.ViewModel;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Frogger.View
{
    /// <summary>
    ///     An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class GamePage
    {
        #region Data members

        private readonly double applicationHeight = (double)Application.Current.Resources["AppHeight"];
        private readonly double applicationWidth = (double)Application.Current.Resources["AppWidth"];
        private readonly GameManager gameManager;

        #endregion

        #region Constructors

        /// <summary>
        ///     The "main" page for the Frogger game.
        /// </summary>
        public GamePage()
        {
            this.InitializeComponent();
            ApplicationView.PreferredLaunchViewSize = new Size
                { Width = this.applicationWidth, Height = this.applicationHeight };
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
            ApplicationView.GetForCurrentView()
                .SetPreferredMinSize(new Size(this.applicationWidth, this.applicationHeight));

            Window.Current.CoreWindow.KeyDown += this.coreWindowOnKeyDown;
            var highScoreBoardViewModel = new HighScoreBoardViewModel();
            DataContext = highScoreBoardViewModel;

            this.gameManager =
                new GameManager(this.applicationHeight, this.applicationWidth, highScoreBoardViewModel);
            this.gameManager.InitializeGame(this.canvas);
            var hudManager = new HudManager(this.gameManager);
            hudManager.InitializeHud(this.canvas, this.gameManager);
        }

        #endregion

        #region Methods

        private void coreWindowOnKeyDown(CoreWindow sender, KeyEventArgs args)
        {
            switch (args.VirtualKey)
            {
                case VirtualKey.Left:
                    this.gameManager.MovePlayer(Direction.Left);
                    break;
                case VirtualKey.Right:
                    this.gameManager.MovePlayer(Direction.Right);
                    break;
                case VirtualKey.Up:
                    this.gameManager.MovePlayer(Direction.Up);
                    break;
                case VirtualKey.Down:
                    this.gameManager.MovePlayer(Direction.Down);
                    break;
            }
        }

        /// <summary>
        /// Invoked when the Page is loaded and becomes the current source of a parent Frame.
        /// </summary>
        /// <param name="e">Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            if (e.Parameter is string param && param == "viewHighScores")
            {
                this.gameManager.IsGamePaused = true; 
                this.highScoreBoard.Visibility = Visibility.Visible;
            }
        }



        #endregion

        private void PlayAgain_Click(object sender, RoutedEventArgs e)
        {
            this.gameManager.ResetGame();
        }
    }
}