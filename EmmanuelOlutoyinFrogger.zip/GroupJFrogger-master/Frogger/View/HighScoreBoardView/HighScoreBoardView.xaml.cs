﻿using Frogger.Helpers;
using Windows.UI.Xaml;


namespace Frogger.View.HighScoreBoardView
{
    /// <summary>
    /// HighScoreBoardView CodeBehind
    /// </summary>
    /// <seealso cref="Windows.UI.Xaml.Controls.UserControl" />
    /// <seealso cref="Windows.UI.Xaml.Markup.IComponentConnector" />
    /// <seealso cref="Windows.UI.Xaml.Markup.IComponentConnector2" />
    public sealed partial class HighScoreBoardView 
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="HighScoreBoardView"/> class.
        /// </summary>
        public HighScoreBoardView()
        {
            this.InitializeComponent();
        }

        #endregion

        private void BackToStart_Click(object sender, RoutedEventArgs e)
        {
            var rootFrame = NavigationHelper.FindFrame(this);
            rootFrame?.Navigate(typeof(StartScreen));
        }
    }
}