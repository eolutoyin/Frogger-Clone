﻿using Frogger.ViewModel;
using Windows.UI.Xaml;


namespace Frogger.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class StartScreen 
    {
        private readonly HighScoreBoardViewModel highScoreBoardViewModel;

        /// <summary>
        /// Initializes a new instance of the <see cref="StartScreen"/> class.
        /// </summary>
        public StartScreen()
        {
            this.InitializeComponent();
            this.highScoreBoardViewModel = new HighScoreBoardViewModel();
            DataContext = this.highScoreBoardViewModel;
        }


        private void StartGame_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(GamePage)); 
        }

        private void ViewHighScores_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(GamePage), "viewHighScores");
        }


        private void ResetHighScores_Click(object sender, RoutedEventArgs e)
        {
            this.highScoreBoardViewModel.ResetHighScores();
        }
    }
}
