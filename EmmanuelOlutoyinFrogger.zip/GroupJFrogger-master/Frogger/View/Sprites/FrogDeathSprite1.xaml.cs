﻿// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Frogger.View.Sprites
{
    /// <summary>
    ///     An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class FrogDeathSprite1
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="FrogDeathSprite1"/> class.
        /// </summary>
        public FrogDeathSprite1()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}