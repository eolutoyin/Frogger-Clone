﻿namespace Frogger.View.Sprites.WaterSprites
{
    /// <summary>
    ///     An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BoatSprite
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="BoatSprite"/> class.
        /// </summary>
        public BoatSprite()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}