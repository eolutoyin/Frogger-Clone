﻿
namespace Frogger.View.Sprites
{
    /// <summary>
    ///     An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class FrogMovementSprite1
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="FrogMovementSprite1"/> class.
        /// </summary>
        public FrogMovementSprite1()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}