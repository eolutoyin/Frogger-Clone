﻿namespace Frogger.View.Sprites.PowerUpSprites
{
    /// <summary>
    ///     An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ExtraTimeSprite
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ExtraTimeSprite"/> class.
        /// </summary>
        public ExtraTimeSprite()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}