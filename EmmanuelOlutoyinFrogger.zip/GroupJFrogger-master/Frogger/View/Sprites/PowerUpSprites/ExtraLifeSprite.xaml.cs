﻿// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites.PowerUpSprites
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    /// <seealso cref="Frogger.View.Sprites.BaseSprite" />
    /// <seealso cref="Windows.UI.Xaml.Markup.IComponentConnector" />
    /// <seealso cref="Windows.UI.Xaml.Markup.IComponentConnector2" />
    public sealed partial class ExtraLifeSprite
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ExtraLifeSprite"/> class.
        /// </summary>
        public ExtraLifeSprite()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}