﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Frogger.Command;
using Frogger.Model;

namespace Frogger.ViewModel
{
    /// <summary>
    /// Represents the ViewModel for the High Score Board
    /// </summary>
    /// <seealso cref="System.ComponentModel.INotifyPropertyChanged" />
    public class HighScoreBoardViewModel : INotifyPropertyChanged
    {
        #region Data members

        private string playerName;
        private int currentScore;
        private string currentLevel;
        private HighScoreBoard selectedHighScore;

        private Visibility highScoreBoardVisibility = Visibility.Collapsed;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the player names.
        /// </summary>
        /// <value>
        /// The player names.
        /// </value>
        public string PlayerNames
        {
            get => this.playerName;
            set
            {
                this.playerName = value;
                this.OnPropertyChanged(nameof(this.PlayerNames));
                this.SubmitScoreCommand.OnCanExecuteChanged();
            }
        }

        /// <summary>
        /// Gets or sets the current score.
        /// </summary>
        /// <value>
        /// The current score.
        /// </value>
        public int CurrentScore
        {
            get => this.currentScore;
            set
            {
                this.currentScore = value;
                this.OnPropertyChanged(nameof(this.CurrentScore));
                this.SubmitScoreCommand.OnCanExecuteChanged();
            }
        }

        /// <summary>
        /// Gets or sets the current level.
        /// </summary>
        /// <value>
        /// The current level.
        /// </value>
        public string CurrentLevel
        {
            get => this.currentLevel;
            set
            {
                if (this.currentLevel != value)
                {
                    this.currentLevel = value;
                    this.OnPropertyChanged(nameof(this.CurrentLevel));
                    this.SubmitScoreCommand.OnCanExecuteChanged();
                }
            }
        }

        /// <summary>
        /// Gets or sets the selected high score.
        /// </summary>
        /// <value>
        /// The selected high score.
        /// </value>
        public HighScoreBoard SelectedHighScore
        {
            get => this.selectedHighScore;
            set
            {
                if (this.selectedHighScore != value)
                {
                    this.selectedHighScore = value;
                    this.OnPropertyChanged(nameof(this.SelectedHighScore));
                    this.RemoveHighScoreCommand.OnCanExecuteChanged();
                    this.EditHighScoreCommand.OnCanExecuteChanged();
                }
            }
        }

        /// <summary>
        /// Gets or sets the high score board visibility.
        /// </summary>
        /// <value>
        /// The high score board visibility.
        /// </value>
        public Visibility HighScoreBoardVisibility
        {
            get => this.highScoreBoardVisibility;
            set
            {
                this.highScoreBoardVisibility = value;
                this.OnPropertyChanged(nameof(this.HighScoreBoardVisibility));
            }
        }

        /// <summary>
        /// Gets the high scores.
        /// </summary>
        /// <value>
        /// The high scores.
        /// </value>
        public ObservableCollection<HighScoreBoard> HighScores { get; private set; }
        /// <summary>
        /// Gets the submit score command.
        /// </summary>
        /// <value>
        /// The submit score command.
        /// </value>
        public RelayCommand SubmitScoreCommand { get; }
        /// <summary>
        /// Gets the sort by score name level command.
        /// </summary>
        /// <value>
        /// The sort by score name level command.
        /// </value>
        public RelayCommand SortByScoreNameLevelCommand { get; private set; }
        /// <summary>
        /// Gets the sort by name score level command.
        /// </summary>
        /// <value>
        /// The sort by name score level command.
        /// </value>
        public RelayCommand SortByNameScoreLevelCommand { get; private set; }
        /// <summary>
        /// Gets the sort by level score name command.
        /// </summary>
        /// <value>
        /// The sort by level score name command.
        /// </value>
        public RelayCommand SortByLevelScoreNameCommand { get; private set; }
        /// <summary>
        /// Gets the remove high score command.
        /// </summary>
        /// <value>
        /// The remove high score command.
        /// </value>
        public RelayCommand RemoveHighScoreCommand { get; }
        /// <summary>
        /// Gets the edit high score command.
        /// </summary>
        /// <value>
        /// The edit high score command.
        /// </value>
        public RelayCommand EditHighScoreCommand { get; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="HighScoreBoardViewModel"/> class.
        /// </summary>
        public HighScoreBoardViewModel()
        {
            this.HighScores = new ObservableCollection<HighScoreBoard>(this.LoadHighScores());
            this.SubmitScoreCommand = new RelayCommand(param => this.submitScore(), param => this.canSubmitScore());
            this.SubmitScoreCommand = new RelayCommand(param => this.submitScore(), param => this.canSubmitScore());
            this.SortByScoreNameLevelCommand =
                new RelayCommand(param => this.sortHighScores("ScoreNameLevel"), param => this.canSortHighScores());
            this.SortByNameScoreLevelCommand =
                new RelayCommand(param => this.sortHighScores("NameScoreLevel"), param => this.canSortHighScores());
            this.SortByLevelScoreNameCommand =
                new RelayCommand(param => this.sortHighScores("LevelScoreName"), param => this.canSortHighScores());
            this.RemoveHighScoreCommand =
                new RelayCommand(param => this.removeHighScore(), param => this.canRemoveHighScore());
            this.EditHighScoreCommand =
                new RelayCommand(param => this.editHighScore(), param => this.canEditHighScore());
        }

        #endregion

        #region Methods

        /// <summary>
        /// Occurs when [property changed].
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Adds the new high score.
        /// </summary>
        /// <param name="currentPlayerName">Name of the current player.</param>
        /// <param name="score">The score.</param>
        /// <param name="levelCompleted">The level completed.</param>
        public void AddNewHighScore(string currentPlayerName, int score, string levelCompleted)
        {
            this.HighScores.Add(new HighScoreBoard
                { PlayerName = currentPlayerName, Score = score, LevelCompleted = levelCompleted });
            this.SaveHighScores();
        }

        private void sortHighScores(string sortType)
        {
            switch (sortType)
            {
                case "ScoreNameLevel":
                    this.HighScores = new ObservableCollection<HighScoreBoard>(this.HighScores
                        .OrderByDescending(h => h.Score)
                        .ThenBy(h => h.PlayerName)
                        .ThenBy(h => levelOrderForSorting(h.LevelCompleted)));
                    break;
                case "NameScoreLevel":
                    this.HighScores = new ObservableCollection<HighScoreBoard>(this.HighScores
                        .OrderBy(h => h.PlayerName)
                        .ThenByDescending(h => h.Score)
                        .ThenBy(h => levelOrderForSorting(h.LevelCompleted)));
                    break;
                case "LevelScoreName":
                    this.HighScores = new ObservableCollection<HighScoreBoard>(this.HighScores
                        .OrderBy(h => levelOrderForSorting(h.LevelCompleted))
                        .ThenByDescending(h => h.Score)
                        .ThenBy(h => h.PlayerName));
                    break;
            }

            this.OnPropertyChanged(nameof(this.HighScores));
        }

        /// <summary>
        /// Loads the high scores from an xml file.
        /// </summary>
        /// <returns></returns>
        public List<HighScoreBoard> LoadHighScores()
        {
            var highScores = new List<HighScoreBoard>();
            var filePath = getHighScoreFilePath();

            if (!File.Exists(filePath))
            {
                return highScores;
            }

            var document = XDocument.Load(filePath);
            if (document.Root != null)
            {
                var highScoreElements = document.Root.Elements("HighScore");

                foreach (var element in highScoreElements)
                {
                    var value = element.Element("Score")?.Value;
                    if (value != null)
                    {
                        highScores.Add(new HighScoreBoard
                        {
                            PlayerName = element.Element("PlayerName")?.Value,
                            Score = int.Parse(value),
                            LevelCompleted = element.Element("LevelCompleted")?.Value
                        });
                    }
                }
            }

            return highScores;
        }

        /// <summary>
        /// Saves the high scores to an xml file.
        /// </summary>
        public void SaveHighScores()
        {
            var highScoresElement = new XElement("HighScores");

            foreach (var highScore in this.HighScores)
            {
                highScoresElement.Add(new XElement("HighScore",
                    new XElement("PlayerName", highScore.PlayerName),
                    new XElement("Score", highScore.Score),
                    new XElement("LevelCompleted", highScore.LevelCompleted)
                ));
            }

            var document = new XDocument(highScoresElement);
            var filePath = getHighScoreFilePath();
            document.Save(filePath);
        }

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected virtual void OnPropertyChanged(string propertyName)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private static string getHighScoreFilePath()
        {
            var localFolder = ApplicationData.Current.LocalFolder;
            var appFolder = Path.Combine(localFolder.Path, "GroupJFrogger");
            Directory.CreateDirectory(appFolder);
            return Path.Combine(appFolder, "HighScores.xml");
        }

        private void submitScore()
        {
            if (!string.IsNullOrEmpty(this.PlayerNames))
            {
                this.AddNewHighScore(this.PlayerNames, this.CurrentScore, this.CurrentLevel);
                this.PlayerNames = "";
                this.CurrentScore = 0;
                this.CurrentLevel = ""; 
            }
        }

        private bool canSubmitScore()
        {
            return !string.IsNullOrEmpty(this.PlayerNames);
        }

        /// <summary>
        /// Updates the current score and level.
        /// </summary>
        /// <param name="score">The score.</param>
        /// <param name="level">The level.</param>
        public void UpdateCurrentScoreAndLevel(int score, string level)
        {
            this.CurrentScore = score;
            this.CurrentLevel = level;
        }

        /// <summary>
        /// Shows the high score board.
        /// </summary>
        public void ShowHighScoreBoard()
        {
            this.HighScoreBoardVisibility = Visibility.Visible;
        }

        /// <summary>
        /// Resets the high scores.
        /// </summary>
        public void ResetHighScores()
        {
            this.HighScores.Clear();
            this.SaveHighScores(); 
        }

        private bool canSortHighScores()
        {
            return this.HighScores.Any();
        }

        private void removeHighScore()
        {
            if (this.SelectedHighScore != null)
            {
                this.HighScores.Remove(this.SelectedHighScore);
                this.SaveHighScores(); 
            }
        }

        private bool canRemoveHighScore()
        {
            return this.SelectedHighScore != null;
        }

        private async void editHighScore()
        {
            if (this.SelectedHighScore != null)
            {
                var newName = await promptForNewNameAsync();
                if (!string.IsNullOrWhiteSpace(newName))
                {
                    this.SelectedHighScore.PlayerName = newName;
                    this.SaveHighScores();
                }
            }
        }

        private bool canEditHighScore()
        {
            return this.SelectedHighScore != null;
        }

        private static async Task<string> promptForNewNameAsync()
        {
            var inputTextBox = new TextBox
            {
                AcceptsReturn = false,
                Height = 32
            };

            var dialog = new ContentDialog
            {
                Content = inputTextBox,
                Title = "Edit Name",
                IsSecondaryButtonEnabled = true,
                PrimaryButtonText = "Ok",
                SecondaryButtonText = "Cancel"
            };

            var result = await dialog.ShowAsync();

            return result == ContentDialogResult.Primary ? inputTextBox.Text : null;
        }

        private static int levelOrderForSorting(string level)
        {
            switch (level)
            {
                case "Beginner":
                    return 1;
                case "Medium":
                    return 2;
                case "Hard":
                    return 3;
                default:
                    return 4; 
            }
        }

        #endregion
    }
}