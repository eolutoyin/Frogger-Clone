﻿using System.Collections.Generic;
using Frogger.Model.Lanes;

namespace Frogger.Model.Levels
{
    /// <summary>
    /// Represents a game level, encapsulating all the lanes that make up the level.
    /// </summary>
    public class Level
    {
        #region Properties

        /// <summary>
        /// Gets the level lanes.
        /// </summary>
        /// <value>
        /// The level lanes.
        /// </value>
        public List<Lane> LevelLanes { get; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Level"/> class.
        /// </summary>
        /// <param name="levelLanes">The level lanes.</param>
        public Level(List<Lane> levelLanes)
        {
            this.LevelLanes = levelLanes;
        }

        #endregion
    }
}