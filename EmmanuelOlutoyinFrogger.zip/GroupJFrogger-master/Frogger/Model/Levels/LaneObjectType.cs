﻿namespace Frogger.Model.Levels
{
    /// <summary>
    /// Enumerates the different types of objects that can appear in game lanes.
    /// </summary>
    public enum LaneObjectType
    {
        /// <summary>
        /// Represents a car object in the lane.
        /// </summary>
        Car,
        /// <summary>
        /// Represents a truck object in the lane.
        /// </summary>
        Truck,
        /// <summary>
        /// Represents a super car object in the lane.
        /// </summary>
        SuperCar,
        /// <summary>
        /// Represents a home landing spot object in the lane.
        /// </summary>
        Home,
        /// <summary>
        /// Represents a log object in the lane.
        /// </summary>
        Log,
        /// <summary>
        /// Represents a boat object in the lane.
        /// </summary>
        Boat,
        /// <summary>
        /// Represents a powerUp object in the lane.
        /// </summary>
        PowerUp,
        /// <summary>
        /// Represents an Extra Time PowerUp object in the lane.
        /// </summary>
        ExtraTimePowerUp,
        /// <summary>
        /// Represents an Extra Life PowerUp object in the lane.
        /// </summary>
        ExtraLifePowerUp
    }
}