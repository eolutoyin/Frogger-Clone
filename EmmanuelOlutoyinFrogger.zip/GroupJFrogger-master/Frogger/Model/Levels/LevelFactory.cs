﻿using System;
using System.Collections.Generic;
using Windows.UI.Xaml;
using Frogger.Model.Lanes;
using Frogger.Settings;

namespace Frogger.Model.Levels
{
    /// <summary>
    /// Responsible for creating game levels based on the specified LevelType.
    /// </summary>
    public class LevelFactory
    {
        #region Methods

        /// <summary>
        /// Creates the level.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentException">Invalid Level type</exception>
        public Level CreateLevel(LevelType type)
        {
            switch (type)
            {
                case LevelType.Beginner:
                    return createBeginnerLevel();
                case LevelType.Medium:
                    return createMediumLevel();
                case LevelType.Hard:
                    return createHardLevel();
                case LevelType.Uninitialized:
                    throw new ArgumentException("Invalid Level type");
                default:
                    throw new ArgumentException("Invalid Level type");
            }
        }

        private static Level createHardLevel()
        {
            var laneConfigurations = new List<LaneConfiguration>
            {
                new LaneConfiguration(LaneType.Road, 1, LaneObjectType.Car),
                new LaneConfiguration(LaneType.Road, 3, LaneObjectType.Car),
                new LaneConfiguration(LaneType.Road, 4, LaneObjectType.Car),
                new LaneConfiguration(LaneType.Road, 4, LaneObjectType.Car),
                new LaneConfiguration(LaneType.Road, 2, LaneObjectType.Car),
                new LaneConfiguration(LaneType.Road, 3, LaneObjectType.Car),
                new LaneConfiguration(LaneType.River, 5, LaneObjectType.Log),
                new LaneConfiguration(LaneType.River, 5, LaneObjectType.Boat),
                new LaneConfiguration(LaneType.River, 5, LaneObjectType.Log),
                new LaneConfiguration(LaneType.Home, 5, LaneObjectType.Home)
            };

            var lanes = new List<Lane>();
            const double maxSpeed = 4;
            for (var i = 0; i < laneConfigurations.Count; i++)
            {
                var lane = generateLaneFromConfig(i, maxSpeed, laneConfigurations);
                lanes.Add(lane);
            }

            return new Level(lanes);
        }

        private static Level createBeginnerLevel()
        {
            var laneConfigurations = new List<LaneConfiguration>
            {
                new LaneConfiguration(LaneType.Road, 3, LaneObjectType.Car),
                new LaneConfiguration(LaneType.Road, 2, LaneObjectType.SuperCar),
                new LaneConfiguration(LaneType.Road, 4, LaneObjectType.Truck),
                new LaneConfiguration(LaneType.Road, 3, LaneObjectType.Car),
                new LaneConfiguration(LaneType.Road, 5, LaneObjectType.Truck),
                new LaneConfiguration(LaneType.Road, 5, LaneObjectType.Truck),
                new LaneConfiguration(LaneType.River, 3, LaneObjectType.Log),
                new LaneConfiguration(LaneType.River, 2, LaneObjectType.Boat),
                new LaneConfiguration(LaneType.River, 3, LaneObjectType.Log),
                new LaneConfiguration(LaneType.Home, 5, LaneObjectType.Home)
            };

            var lanes = new List<Lane>();
            const double maxSpeed = 2;
            for (var i = 0; i < laneConfigurations.Count; i++)
            {
                var lane = generateLaneFromConfig(i, maxSpeed, laneConfigurations);
                lanes.Add(lane);
            }

            return new Level(lanes);
        }

        private static Level createMediumLevel()
        {
            var laneConfigurations = new List<LaneConfiguration>
            {
                new LaneConfiguration(LaneType.Road, 2, LaneObjectType.SuperCar),
                new LaneConfiguration(LaneType.Road, 3, LaneObjectType.Car),
                new LaneConfiguration(LaneType.Road, 4, LaneObjectType.Truck),
                new LaneConfiguration(LaneType.Road, 4, LaneObjectType.Car),
                new LaneConfiguration(LaneType.Road, 2, LaneObjectType.SuperCar),
                new LaneConfiguration(LaneType.Road, 3, LaneObjectType.Truck),
                new LaneConfiguration(LaneType.River, 5, LaneObjectType.Log),
                new LaneConfiguration(LaneType.River, 5, LaneObjectType.Boat),
                new LaneConfiguration(LaneType.River, 5, LaneObjectType.Log),
                new LaneConfiguration(LaneType.Home, 5, LaneObjectType.Home)
            };

            var lanes = new List<Lane>();
            const double maxSpeed = 3;
            for (var i = 0; i < laneConfigurations.Count; i++)
            {
                var lane = generateLaneFromConfig(i, maxSpeed, laneConfigurations);
                lanes.Add(lane);
            }

            return new Level(lanes);
        }

        private static Lane generateLaneFromConfig(int i, double maxSpeed,
            IReadOnlyList<LaneConfiguration> laneConfigurations)
        {
            var laneFactory = new LaneFactory();
            var direction = i % 2 == 0 ? Direction.Right : Direction.Left;
            var lowerShoulderYLocation = (double)Application.Current.Resources["LowShoulderYLocation"];
            var speed = getRandomSpeed(maxSpeed);
            var lane = laneFactory.GenerateLevel(laneConfigurations[i].LaneType, direction, speed,
                lowerShoulderYLocation - (i + 1) * GameSettings.ObstacleHeightInPixels,
                laneConfigurations[i].MaxNumberOfLaneObjects,
                laneConfigurations[i].LaneObjectType);
            return lane;
        }

        private static double getRandomSpeed(double maxSpeed)
        {
            if (maxSpeed < 0)
            {
                throw new ArgumentException("maxSpeed must be non-negative", nameof(maxSpeed));
            }

            var random = new Random();
            var speed = random.NextDouble() * (maxSpeed - GameSettings.MinimumSpeedOfLaneObject) +
                        GameSettings.MinimumSpeedOfLaneObject;
            return speed;
        }

        /// <summary>
        /// Represents the configuration settings for a lane in the game.
        /// </summary>
        public class LaneConfiguration
        {
            #region Properties

            /// <summary>
            /// Gets or sets the type of the lane.
            /// </summary>
            /// <value>
            /// The type of the lane.
            /// </value>
            public LaneType LaneType { get; set; }
            /// <summary>
            /// Gets or sets the maximum number of lane objects.
            /// </summary>
            /// <value>
            /// The maximum number of lane objects.
            /// </value>
            public int MaxNumberOfLaneObjects { get; set; }
            /// <summary>
            /// Gets or sets the type of the lane object.
            /// </summary>
            /// <value>
            /// The type of the lane object.
            /// </value>
            public LaneObjectType LaneObjectType { get; set; }

            #endregion

            #region Constructors

            /// <summary>
            /// Initializes a new instance of the <see cref="LaneConfiguration"/> class.
            /// </summary>
            /// <param name="laneType">Type of the lane.</param>
            /// <param name="maxNumberOfLaneObjects">The maximum number of lane objects.</param>
            /// <param name="laneObjectType">Type of the lane object.</param>
            public LaneConfiguration(LaneType laneType, int maxNumberOfLaneObjects, LaneObjectType laneObjectType)
            {
                this.LaneType = laneType;
                this.MaxNumberOfLaneObjects = maxNumberOfLaneObjects;
                this.LaneObjectType = laneObjectType;
            }

            #endregion
        }

        #endregion
    }
}