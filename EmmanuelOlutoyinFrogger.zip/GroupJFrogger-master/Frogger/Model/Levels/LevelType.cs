﻿namespace Frogger.Model.Levels
{
    /// <summary>
    /// Defines the various difficulty levels available in the game.
    /// </summary>
    public enum LevelType
    {
        /// <summary>
        /// Indicates an uninitialized state for the level.
        /// </summary>
        Uninitialized = 0,
        /// <summary>
        /// Represents the beginner level.
        /// </summary>
        Beginner,
        /// <summary>
        /// Represents a medium difficulty level,
        /// </summary>
        Medium,
        /// <summary>
        /// Represents the hard level
        /// </summary>
        Hard
    }
}