﻿namespace Frogger.Model.Levels
{
    /// <summary>
    /// Manages the levels in the game, including loading and transitioning between different levels. 
    /// </summary>
    public class LevelManager

    {
        #region Properties

        /// <summary>
        /// Gets or sets the current level.
        /// </summary>
        /// <value>
        /// The current level.
        /// </value>
        public Level CurrentLevel { get; set; }
        /// <summary>
        /// Gets the type of the current level.
        /// </summary>
        /// <value>
        /// The type of the current level.
        /// </value>
        public LevelType CurrentLevelType { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Loads the level.
        /// </summary>
        /// <param name="levelType">Type of the level.</param>
        public void LoadLevel(LevelType levelType)
        {
            var levelFactory = new LevelFactory();
            this.CurrentLevel = levelFactory.CreateLevel(levelType);
            this.CurrentLevelType = levelType;
        }

        /// <summary>
        /// Loads the next level.
        /// </summary>
        /// <returns></returns>
        public bool LoadNextLevel()
        {
            switch (this.CurrentLevelType)
            {
                case LevelType.Uninitialized:
                    this.LoadLevel(LevelType.Beginner);
                    return true;
                case LevelType.Beginner:
                    this.LoadLevel(LevelType.Medium);
                    return true;
                case LevelType.Medium:
                    this.LoadLevel(LevelType.Hard);
                    return true;
                case LevelType.Hard:
                    return false;
                default:
                    return false;
            }
        }

        #endregion
    }
}