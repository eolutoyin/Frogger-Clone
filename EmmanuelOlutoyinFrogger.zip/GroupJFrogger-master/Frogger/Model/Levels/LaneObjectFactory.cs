﻿using System;
using Frogger.Model.GameObjects;
using Frogger.Model.PowerUp;

namespace Frogger.Model.Levels
{
    /// <summary>
    /// Responsible for creating lane objects in the game, based on the specified LaneObjectType.
    /// </summary>
    public class LaneObjectFactory
    {
        #region Methods

        /// <summary>
        /// Creates the lane object.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="speed">The speed.</param>
        /// <param name="direction">The direction.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentException">
        /// PowerUp type is not valid
        /// or
        /// Invalid Lane Object type
        /// </exception>
        public GameObject CreateLaneObject(LaneObjectType type, double speed, Direction direction)
        {
            switch (type)
            {
                case LaneObjectType.Car:
                    return new Car(speed, direction, LaneObjectType.Car);
                case LaneObjectType.Truck:
                    return new Truck(speed, direction, LaneObjectType.Truck);
                case LaneObjectType.Home:
                    return new Home(LaneObjectType.Home);
                case LaneObjectType.SuperCar:
                    return new SportsCar(speed, direction, LaneObjectType.SuperCar);
                case LaneObjectType.Log:
                    return new Log(speed, direction, LaneObjectType.Log);
                case LaneObjectType.Boat:
                    return new Boat(speed, direction, LaneObjectType.Boat);
                case LaneObjectType.ExtraTimePowerUp:
                    return new PowerUp.PowerUp(PowerUpType.ExtraTime, LaneObjectType.ExtraTimePowerUp);
                case LaneObjectType.ExtraLifePowerUp:
                    return new PowerUp.PowerUp(PowerUpType.ExtraLife, LaneObjectType.ExtraLifePowerUp);
                case LaneObjectType.PowerUp:
                    throw new ArgumentException("PowerUp type is not valid");
                default:
                    throw new ArgumentException("Invalid Lane Object type");
            }
        }

        #endregion
    }
}