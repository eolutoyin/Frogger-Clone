﻿using System;
using System.ComponentModel;

namespace Frogger.Model
{

    /// <summary>
    /// Represents a high score entry in the game, encapsulating details such as player name, score, and level.
    /// </summary>
    /// <seealso cref="System.ComponentModel.INotifyPropertyChanged" />
    /// <seealso cref="HighScoreBoard" />
    public class HighScoreBoard : INotifyPropertyChanged, IComparable<HighScoreBoard>
    {
        #region Data members

        private string playerName;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the name of the player.
        /// </summary>
        /// <value>
        /// The name of the player.
        /// </value>
        public string PlayerName
        {
            get => this.playerName;
            set
            {
                if (this.playerName != value)
                {
                    this.playerName = value;
                    this.OnPropertyChanged(nameof(this.PlayerName));
                }
            }
        }

        /// <summary>
        /// Gets or sets the score.
        /// </summary>
        /// <value>
        /// The score.
        /// </value>
        public int Score { get; set; }
        /// <summary>
        /// Gets or sets the level completed.
        /// </summary>
        /// <value>
        /// The level completed.
        /// </value>
        public string LevelCompleted { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Compares Scores.
        /// </summary>
        /// <param name="other">The other.</param>
        /// <returns></returns>
        public int CompareTo(HighScoreBoard other)
        {
            var scoreComparison = this.Score.CompareTo(other.Score);
            if (scoreComparison != 0)
            {
                return scoreComparison;
            }

            var nameComparison = String.Compare(this.PlayerName, other.PlayerName, StringComparison.Ordinal);
            return nameComparison != 0 ? nameComparison :
                String.Compare(this.LevelCompleted, other.LevelCompleted, StringComparison.Ordinal);
        }

        /// <summary>
        /// Occurs when [property changed].
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected virtual void OnPropertyChanged(string propertyName)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}