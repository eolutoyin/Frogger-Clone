﻿namespace Frogger.Model
{
    /// <summary>
    /// Enumerates the possible directions for movement or orientation within the game.
    /// </summary>
    public enum Direction
    {
        /// <summary>
        /// Indicates upward movement or orientation.
        /// </summary>
        Up,
        /// <summary>
        /// Indicates downward movement or orientation.
        /// </summary>
        Down,
        /// <summary>
        /// Indicates leftward movement or orientation.
        /// </summary>
        Left,
        /// <summary>
        /// Indicates rightward movement or orientation.
        /// </summary>
        Right
    }
}