﻿using System;

namespace Frogger.Model
{
    /// <summary>
    /// Represents the arguments for an event that is triggered when an object's position changes.
    /// </summary>
    /// <seealso cref="System.EventArgs" />
    public class PositionChangedEventArgs : EventArgs
    {
        #region Properties

        /// <summary>
        /// Gets the y axis.
        /// </summary>
        /// <value>
        /// The y.
        /// </value>
        public double Y { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PositionChangedEventArgs"/> class.
        /// </summary>
        /// <param name="y">The y.</param>
        public PositionChangedEventArgs(double y)
        {
            this.Y = y;
        }

        #endregion
    }
}