﻿using Frogger.Model.Levels;
using Frogger.View.Sprites;

namespace Frogger.Model.GameObjects
{
    /// <summary>
    /// Represents a car object in the game, derived from the GameObject class.
    /// </summary>
    /// <seealso cref="Frogger.Model.GameObjects.GameObject" />
    public class Car : GameObject
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Car"/> class.
        /// </summary>
        /// <param name="speed">The speed.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="laneObjectType">Type of the lane object.</param>
        public Car(double speed, Direction direction, LaneObjectType laneObjectType)
        {
            SetSpeed(speed, 0);
            Sprite = new CarSprite();
            if (direction == Direction.Right)
            {
                FlipSpriteHorizontally();
            }

            LaneObjectType = laneObjectType;
        }

        #endregion
    }
}