﻿using System;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;
using Frogger.Model.Levels;
using Frogger.Settings;
using Frogger.View.Sprites;

namespace Frogger.Model.GameObjects
{
    /// <summary>
    ///     Defines basic properties and behavior of every game object.
    /// </summary>
    public abstract class GameObject
    {
        #region Types and Delegates

        /// <summary>
        /// Event Handler for position changed
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        public delegate void PositionChangedEventHandler(object sender, EventArgs e);

        #endregion

        #region Data members

        private Point location;

        #endregion

        #region Properties

        /// <summary>
        ///     Gets or sets the x location of the game object.
        /// </summary>
        /// <value>
        ///     The x.
        /// </value>
        public double X
        {
            get => this.location.X;
            set
            {
                if (Math.Abs(this.location.X - value) > GameSettings.PixelCollisionTollerace)
                {
                    this.location.X = value;
                    this.render();

                    this.OnPositionChanged();
                }
            }
        }

        /// <summary>
        ///     Gets or sets the y location of the game object.
        /// </summary>
        /// <value>
        ///     The y.
        /// </value>
        public double Y
        {
            get => this.location.Y;
            set
            {
                if (Math.Abs(this.location.Y - value) > GameSettings.PixelCollisionTollerace)
                {
                    this.location.Y = value;
                    this.render();

                    this.OnPositionChanged();
                }
            }
        }

        /// <summary>
        ///     Gets the x speed of the game object.
        /// </summary>
        /// <value>
        ///     The speed x.
        /// </value>
        public double SpeedX { get; private set; }

        /// <summary>
        ///     Gets the y speed of the game object.
        /// </summary>
        /// <value>
        ///     The speed y.
        /// </value>
        public double SpeedY { get; private set; }

        /// <summary>
        /// Gets or sets the type of the lane object.
        /// </summary>
        /// <value>
        /// The type of the lane object.
        /// </value>
        public LaneObjectType LaneObjectType { get; protected set; }

        /// <summary>
        ///     Gets the width of the game object.
        /// </summary>
        /// <value>
        ///     The width.
        /// </value>
        public double Width => this.Sprite.Width;

        /// <summary>
        ///     Gets the height of the game object.
        /// </summary>
        /// <value>
        ///     The height.
        /// </value>
        public double Height => this.Sprite.Height;

        /// <summary>
        ///     Gets or sets the sprite associated with the game object.
        /// </summary>
        /// <value>
        ///     The sprite.
        /// </value>
        public BaseSprite Sprite { get; set; }

        /// <summary>
        /// Gets the bounds.
        /// </summary>
        /// <value>
        /// The bounds.
        /// </value>
        public Rect Bounds => new Rect(this.X, this.Y, this.Width, this.Height);

        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is active; otherwise, <c>false</c>.
        /// </value>
        public bool IsActive { get; set; } = true;
        /// <summary>
        /// Gets a value indicating whether [ready to show].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [ready to show]; otherwise, <c>false</c>.
        /// </value>
        public bool ReadyToShow { get; internal set; }

        #endregion

        #region Methods

        /// <summary>
        /// Moves the specified direction.
        /// </summary>
        /// <param name="direction">The direction.</param>
        public void Move(Direction direction)
        {
            this.Move(direction, this.SpeedX, this.SpeedY);
        }

        /// <summary>
        /// Moves the specified direction.
        /// </summary>
        /// <param name="direction">The direction.</param>
        /// <param name="speedX">The speed x.</param>
        /// <param name="speedY">The speed y.</param>
        /// <exception cref="System.ArgumentOutOfRangeException">direction - null</exception>
        public void Move(Direction direction, double speedX, double speedY)
        {
            if (speedX == 0 && speedY == 0)
            {
                return;
            }

            switch (direction)
            {
                case Direction.Up:
                    this.moveY(-speedY);
                    break;
                case Direction.Down:
                    this.moveY(speedY);
                    break;
                case Direction.Left:
                    this.moveX(-speedX);
                    break;
                case Direction.Right:
                    this.moveX(speedX);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(direction), direction, null);
            }
        }

        private void moveX(double x)
        {
            this.X += x;
        }

        private void moveY(double y)
        {
            this.Y += y;
        }

        private void render()
        {
            this.Sprite.RenderAt(this.X, this.Y);
        }

        /// <summary>
        ///     Sets the speed of the game object.
        ///     Precondition: speedX >= 0 AND speedY >=0
        ///     Postcondition: SpeedX == speedX AND SpeedY == speedY
        /// </summary>
        /// <param name="speedX">The speed x.</param>
        /// <param name="speedY">The speed y.</param>
        public void SetSpeed(double speedX, double speedY)
        {
            if (speedX < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(speedX));
            }

            if (speedY < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(speedY));
            }

            this.SpeedX = speedX;
            this.SpeedY = speedY;
        }

        /// <summary>
        /// Occurs when [position changed].
        /// </summary>
        public event EventHandler<PositionChangedEventArgs> PositionChanged;

        /// <summary>
        /// Flips the sprite horizontally.
        /// </summary>
        protected void FlipSpriteHorizontally()
        {
            this.Sprite.RenderTransformOrigin = new Point(0.5, 0.5);
            this.Sprite.RenderTransform = new ScaleTransform { ScaleX = -1 };
        }

        /// <summary>
        /// Called when [position changed].
        /// </summary>
        protected virtual void OnPositionChanged()
        {
            var args = new PositionChangedEventArgs(this.Y);
            this.PositionChanged?.Invoke(this, args);
        }

        /// <summary>
        /// Intersects with a game object.
        /// </summary>
        /// <param name="otherGameObject">The other game object.</param>
        /// <returns></returns>
        public bool IntersectsWith(GameObject otherGameObject)
        {
            if (!this.IsActive || !otherGameObject.IsActive)
            {
                return false;
            }

            var intersection = this.Bounds;
            intersection.Intersect(otherGameObject.Bounds);
            return !intersection.IsEmpty;
        }

        /// <summary>
        /// Hides this instance.
        /// </summary>
        public void Hide()
        {
            this.Sprite.Visibility = Visibility.Collapsed;
            this.IsActive = false;
            this.ReadyToShow = false;
        }

        /// <summary>
        /// Shows this instance.
        /// </summary>
        public void Show()
        {
            this.Sprite.Visibility = Visibility.Visible;
            this.IsActive = true;
        }

        #endregion
    }
}