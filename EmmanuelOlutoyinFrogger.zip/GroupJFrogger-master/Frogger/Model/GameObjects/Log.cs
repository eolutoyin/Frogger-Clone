﻿using Frogger.Model.Levels;
using Frogger.View.Sprites.WaterSprites;

namespace Frogger.Model.GameObjects
{
    /// <summary>
    /// Represents a log in the game, inheriting from the GameObject class.
    /// </summary>
    /// <seealso cref="Frogger.Model.GameObjects.GameObject" />
    public class Log : GameObject
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Log"/> class.
        /// </summary>
        /// <param name="speed">The speed.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="laneObjectType">Type of the lane object.</param>
        public Log(double speed, Direction direction, LaneObjectType laneObjectType)
        {
            SetSpeed(speed, 0);
            Sprite = new LogSprite();
            if (direction == Direction.Right)
            {
                FlipSpriteHorizontally();
            }

            LaneObjectType = laneObjectType;
        }

        #endregion
    }
}