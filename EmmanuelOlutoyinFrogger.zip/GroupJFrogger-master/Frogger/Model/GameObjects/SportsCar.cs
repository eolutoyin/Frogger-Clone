﻿using Frogger.Model.Levels;
using Frogger.View.Sprites;

namespace Frogger.Model.GameObjects
{
    /// <summary>
    /// Represents a sports car object in the game, extending the Car class.
    /// </summary>
    /// <seealso cref="Frogger.Model.GameObjects.Car" />
    public class SportsCar : Car
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SportsCar"/> class.
        /// </summary>
        /// <param name="speed">The speed.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="laneObjectType">Type of the lane object.</param>
        public SportsCar(double speed, Direction direction, LaneObjectType laneObjectType) : base(speed, direction,
            laneObjectType)
        {
            Sprite = new SportsCarSprite();
        }

        #endregion
    }
}