﻿using Frogger.Model.Levels;
using Frogger.View.Sprites;

namespace Frogger.Model.GameObjects
{
    /// <summary>
    /// Represents a home or destination point in the game, derived from the GameObject class.
    /// </summary>
    /// <seealso cref="Frogger.Model.GameObjects.GameObject" />
    public class Home : GameObject
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Home"/> class.
        /// </summary>
        /// <param name="laneObjectType">Type of the lane object.</param>
        public Home(LaneObjectType laneObjectType)
        {
            Sprite = new FrogHomeUnoccupiedSprite();
            LaneObjectType = laneObjectType;
        }

        #endregion
    }
}