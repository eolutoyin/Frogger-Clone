﻿using System;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Frogger.Model.GameObjects;
using Frogger.View.Sprites;

namespace Frogger.Model.Animation
{
    /// <summary>
    /// Represents an animation for a game object that switches between multiple frames.
    /// </summary>
    public class Animation
    {
        #region Data members

        private readonly BaseSprite[] frames;
        private int currentFrame = 1;
        private readonly int frameDurationInMilliseconds;
        private BaseSprite animationOriginalSprite;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Animation"/> class.
        /// </summary>
        /// <param name="animationFrames">The animation frames.</param>
        /// <param name="frameDurationInMilliseconds">The frame duration in milliseconds.</param>
        public Animation(BaseSprite[] animationFrames, int frameDurationInMilliseconds)
        {
            this.frames = animationFrames;
            this.frameDurationInMilliseconds = frameDurationInMilliseconds;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Starts the animation .
        /// </summary>
        /// <param name="gameObject">The game object.</param>
        /// <param name="canvas">The canvas.</param>
        /// <param name="direction">The direction.</param>
        public async Task StartAnimationAsync(GameObject gameObject, Canvas canvas, Direction direction)
        {
            this.animationOriginalSprite = gameObject.Sprite;

            for (this.currentFrame = 0; this.currentFrame < this.frames.Length; this.currentFrame++)
            {
                canvas.Children.Remove(gameObject.Sprite);
                gameObject.Sprite = this.frames[this.currentFrame];
                applyRotation(gameObject, direction);
                canvas.Children.Add(gameObject.Sprite);
                gameObject.Sprite.RenderAt(gameObject.X, gameObject.Y);

                await Task.Delay(this.frameDurationInMilliseconds);
                canvas.Children.Remove(gameObject.Sprite);
            }

            canvas.Children.Remove(gameObject.Sprite);
            gameObject.Sprite = this.animationOriginalSprite;
            canvas.Children.Add(gameObject.Sprite);
        }

        private static void applyRotation(GameObject gameObject, Direction direction)
        {
            RotateTransform rotateTransform;
            switch (direction)
            {
                case Direction.Up:
                    rotateTransform = new RotateTransform { Angle = 0 };
                    break;
                case Direction.Down:
                    rotateTransform = new RotateTransform { Angle = 180 };
                    break;
                case Direction.Left:
                    rotateTransform = new RotateTransform { Angle = 270 };
                    break;
                case Direction.Right:
                    rotateTransform = new RotateTransform { Angle = 90 };
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(direction), direction, null);
            }

            gameObject.Sprite.RenderTransform = rotateTransform;
            gameObject.Sprite.RenderTransformOrigin = new Point(0.5, 0.5);
        }

        #endregion
    }
}