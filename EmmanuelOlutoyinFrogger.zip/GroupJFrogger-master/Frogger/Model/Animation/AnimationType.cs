﻿namespace Frogger.Model.Animation
{
    /// <summary>
    /// Represents the types of animations used in the Frogger game.
    /// </summary>
    public enum AnimationType
    {
        /// <summary>
        /// The frog death animation
        /// </summary>
        FrogDeath,
        /// <summary>
        /// The frog movement animation
        /// </summary>
        FrogMovement
    }
}