﻿using System.Threading;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Frogger.Model.GameObjects;

namespace Frogger.Model.Animation
{
    /// <summary>
    /// Manages animations for game objects in the Frogger game.
    /// </summary>
    public class AnimationManager
    {
        #region Data members

        private readonly AnimationFactory animationFactory;
        private readonly SemaphoreSlim animationSemaphore = new SemaphoreSlim(1, 1);

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AnimationManager"/> class.
        /// </summary>
        public AnimationManager()
        {
            this.animationFactory = new AnimationFactory();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets the animation.
        /// </summary>
        /// <param name="animationType">Type of the animation.</param>
        /// <returns></returns>
        public Animation GetAnimation(AnimationType animationType)
        {
            return this.animationFactory.CreateAnimation(animationType);
        }

        /// <summary>
        /// Starts the animation asynchronous.
        /// </summary>
        /// <param name="gameObject">The game object.</param>
        /// <param name="canvas">The canvas.</param>
        /// <param name="animationType">Type of the animation.</param>
        /// <param name="direction">The direction.</param>
        public async Task StartAnimationAsync(GameObject gameObject, Canvas canvas, AnimationType animationType,
            Direction direction)
        {
            if (!await this.animationSemaphore.WaitAsync(0))
            {
                return;
            }

            try
            {
                var animation = this.GetAnimation(animationType);
                await animation.StartAnimationAsync(gameObject, canvas, direction);
            }
            finally
            {
                this.animationSemaphore.Release();
            }
        }

        #endregion
    }
}