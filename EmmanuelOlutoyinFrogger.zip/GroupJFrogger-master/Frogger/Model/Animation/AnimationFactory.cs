﻿using System;
using Frogger.Settings;
using Frogger.View.Sprites;

namespace Frogger.Model.Animation
{
    /// <summary>
    /// Factory class responsible for creating animations based on the specified animation type.
    /// </summary>
    public class AnimationFactory
    {
        #region Methods

        /// <summary>
        /// Creates the animation.
        /// </summary>
        /// <param name="animationType">Type of the animation.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentOutOfRangeException">animationType - null</exception>
        public Animation CreateAnimation(AnimationType animationType)
        {
            switch (animationType)
            {
                case AnimationType.FrogDeath:
                    return createFrogDeathAnimation();
                case AnimationType.FrogMovement:
                    return createFrogMovementAnimation();
                default:
                    throw new ArgumentOutOfRangeException(nameof(animationType), animationType, null);
            }
        }

        private static Animation createFrogMovementAnimation()
        {
            BaseSprite[] animationFrames =
            {
                new FrogMovementSprite(),
                new FrogMovementSprite1()
            };
            return new Animation(animationFrames, GameSettings.FrogMovementFrameDurationInMilliseconds);
        }

        private static Animation createFrogDeathAnimation()
        {
            BaseSprite[] animationFrames =
            {
                new FrogDeathSprite1(),
                new FrogDeathSprite2(),
                new FrogDeathSprite3(),
                new FrogDeathSprite4()
            };
            return new Animation(animationFrames, GameSettings.DeathFrameDurationInMilliseconds);
        }

        #endregion
    }
}