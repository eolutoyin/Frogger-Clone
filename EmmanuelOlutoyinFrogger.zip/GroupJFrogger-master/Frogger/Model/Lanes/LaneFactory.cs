﻿using System;
using Frogger.Model.Levels;

namespace Frogger.Model.Lanes
{
    /// <summary>
    /// Represents a factory for generating different types of lanes in the game.
    /// </summary>
    public class LaneFactory
    {
        #region Methods

        /// <summary>
        /// Generates the level lanes.
        /// </summary>
        /// <param name="laneType">Type of the lane.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="laneObjectSpeed">The lane object speed.</param>
        /// <param name="upperLeftYPosition">The upper left y position.</param>
        /// <param name="maxNumOfLaneObjects">The maximum number of lane objects.</param>
        /// <param name="laneObjectType">Type of the lane object.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentException">Invalid Lane type</exception>
        public Lane GenerateLevel(LaneType laneType, Direction direction, double laneObjectSpeed,
            double upperLeftYPosition,
            int maxNumOfLaneObjects, LaneObjectType laneObjectType)
        {
            switch (laneType)
            {
                case LaneType.Road:
                    return generateRoadLane(direction, laneObjectSpeed, upperLeftYPosition, maxNumOfLaneObjects,
                        laneObjectType);
                case LaneType.Home:
                    return generateHomeLane(direction, upperLeftYPosition, maxNumOfLaneObjects, laneObjectType);
                case LaneType.River:
                    return generateRiverLane(direction, laneObjectSpeed, upperLeftYPosition, maxNumOfLaneObjects,
                        laneObjectType);
                default:
                    throw new ArgumentException("Invalid Lane type");
            }
        }

        private static Lane generateRoadLane(Direction direction, double laneObjectSpeed, double upperLeftYPosition,
            int maxNumOfLaneObjects, LaneObjectType laneObjectType)
        {
            return new RoadLane(direction, laneObjectSpeed, upperLeftYPosition, maxNumOfLaneObjects, laneObjectType);
        }

        private static Lane generateHomeLane(Direction direction, double upperLeftYPosition, int numberOfHomes,
            LaneObjectType laneObjectType)
        {
            return new HomeLane(direction, upperLeftYPosition, numberOfHomes, laneObjectType);
        }

        private static Lane generateRiverLane(Direction direction, double laneObjectSpeed, double upperLeftYPosition,
            int maxNumOfLaneObjects, LaneObjectType laneObjectType)
        {
            return new RiverLane(direction, laneObjectSpeed, upperLeftYPosition, maxNumOfLaneObjects, laneObjectType);
        }

        #endregion
    }
}