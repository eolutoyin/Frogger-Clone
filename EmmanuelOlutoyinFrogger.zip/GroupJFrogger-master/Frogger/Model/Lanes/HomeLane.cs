﻿using Frogger.Model.Levels;

namespace Frogger.Model.Lanes
{
    /// <summary>
    /// Represents a Home lane in the game.
    /// </summary>
    /// <seealso cref="Frogger.Model.Lanes.Lane" />
    public class HomeLane : Lane
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="HomeLane"/> class.
        /// </summary>
        /// <param name="direction">The direction.</param>
        /// <param name="upperLeftYPosition">The upper left y position.</param>
        /// <param name="maxNumOfLaneObjects">The maximum number of lane objects.</param>
        /// <param name="laneObjectType">Type of the lane object.</param>
        public HomeLane(Direction direction, double upperLeftYPosition, int maxNumOfLaneObjects,
            LaneObjectType laneObjectType) : base(direction, 0, upperLeftYPosition,
            maxNumOfLaneObjects, laneObjectType)
        {
            Lanetype = LaneType.Home;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Adjusts the lane object locations.
        /// </summary>
        protected override void AdjustLaneObjectLocations()
        {
            var availableSpace = LaneWidth + LaneObjects[0].Width;

            var gapBetweenLaneObjects = availableSpace / (LaneObjects.Count + 2);

            var currentXPosition = 0.0;

            foreach (var laneObject in LaneObjects)
            {
                laneObject.X = currentXPosition;

                laneObject.Y = UpperLeftYPosition;

                currentXPosition += laneObject.Width + gapBetweenLaneObjects;
            }
        }

        /// <summary>
        /// Resets the lane.
        /// </summary>
        public override void ResetLane()
        {
        }

        #endregion
    }
}