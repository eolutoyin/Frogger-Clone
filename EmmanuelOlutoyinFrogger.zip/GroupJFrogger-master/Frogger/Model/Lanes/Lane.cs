﻿using System.Collections.Generic;
using Windows.UI.Xaml;
using Frogger.Model.GameObjects;
using Frogger.Model.Levels;

namespace Frogger.Model.Lanes
{
    /// <summary>
    /// Represents a lane in the game where game objects move.
    /// </summary>
    public class Lane
    {
        #region Data members

        /// <summary>
        /// The speed of the lane
        /// </summary>
        public readonly double Speed;
        /// <summary>
        /// The lane object type
        /// </summary>
        public readonly LaneObjectType LaneObjectType;
        /// <summary>
        /// The upper left y position
        /// </summary>
        public readonly double UpperLeftYPosition;

        /// <summary>
        /// The lane objects
        /// </summary>
        protected readonly List<GameObject> LaneObjects;
        /// <summary>
        /// The initial speed
        /// </summary>
        private readonly double initialSpeed;
        /// <summary>
        /// The lane width
        /// </summary>
        protected readonly double LaneWidth;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the lanetype.
        /// </summary>
        /// <value>
        /// The lanetype.
        /// </value>
        public LaneType Lanetype { get; set; }

        /// <summary>
        /// Gets the direction.
        /// </summary>
        /// <value>
        /// The direction.
        /// </value>
        public Direction Direction { get; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Lane"/> class.
        /// </summary>
        /// <param name="direction">The direction.</param>
        /// <param name="speed">The speed.</param>
        /// <param name="upperLeftYPosition">The upper left y position.</param>
        /// <param name="maxNumOfLaneObjects">The maximum number of lane objects.</param>
        /// <param name="laneObjectType">Type of the lane object.</param>
        public Lane(Direction direction, double speed, double upperLeftYPosition,
            int maxNumOfLaneObjects, LaneObjectType laneObjectType)
        {
            this.Direction = direction;
            this.Speed = speed;
            this.initialSpeed = speed;
            this.LaneWidth = (double)Application.Current.Resources["AppWidth"];
            this.UpperLeftYPosition = upperLeftYPosition;
            this.LaneObjects = new List<GameObject>();
            this.LaneObjectType = laneObjectType;
            this.setupLaneObjects(maxNumOfLaneObjects, laneObjectType);
            AdjustLaneObjectLocations();
        }

        #endregion

        #region Methods

        private void setupLaneObjects(int numOfLaneObjects, LaneObjectType laneObjectType)
        {
            var laneObjectFactory = new LaneObjectFactory();
            for (var i = 0; i < numOfLaneObjects; i++)
            {
                var laneObject = laneObjectFactory.CreateLaneObject(laneObjectType, this.Speed, this.Direction);
                if (i == 0 || this.LaneObjectType == LaneObjectType.Home)
                {
                    laneObject.Show();
                    this.LaneObjects.Add(laneObject);
                    continue;
                }

                laneObject.Hide();
                this.LaneObjects.Add(laneObject);
            }
        }

        /// <summary>
        /// Reveals the next lane object.
        /// </summary>
        public void RevealNextLaneObject()
        {
            for (var i = 0; i < this.LaneObjects.Count; i++)
            {
                if (this.LaneObjects[i].IsActive)
                {
                    for (var j = i; j < this.LaneObjects.Count; j++)
                    {
                        if (!this.LaneObjects[j].IsActive)
                        {
                            this.LaneObjects[j].ReadyToShow = true;
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Resets the lane.
        /// </summary>
        public virtual void ResetLane()
        {
            var isFirst = true;
            foreach (var laneObject in this.LaneObjects)
            {
                if (isFirst)
                {
                    laneObject.Show();
                    isFirst = false;
                }
                else
                {
                    laneObject.Hide();
                }
            }
        }

        /// <summary>
        /// Adjusts the lane object locations.
        /// </summary>
        protected virtual void AdjustLaneObjectLocations()
        {
            var availableSpace = this.LaneWidth + this.LaneObjects[0].Width;

            var gapBetweenLaneObjects = availableSpace / (this.LaneObjects.Count + 1);

            var currentXPosition = gapBetweenLaneObjects;

            foreach (var laneObject in this.LaneObjects)
            {
                laneObject.X = currentXPosition;

                laneObject.Y = this.UpperLeftYPosition;

                currentXPosition += laneObject.Width + gapBetweenLaneObjects;
            }
        }

        /// <summary>
        /// Moves the lane objects.
        /// </summary>
        public void MoveLaneObjects()
        {
            var appWidth = (double)Application.Current.Resources["AppWidth"];

            for (var i = this.LaneObjects.Count - 1; i >= 0; i--)
            {
                var laneObject = this.LaneObjects[i];
                if (laneObject is PowerUp.PowerUp)
                {
                    continue;
                }

                if (this.Direction == Direction.Left)
                {
                    moveLaneObjectLeft(laneObject, appWidth);
                }
                else
                {
                    moveLaneObjectRight(laneObject, appWidth);
                }
            }
        }

        private static void moveLaneObjectRight(GameObject laneObject, double appWidth)
        {
            laneObject.Move(Direction.Right);

            if (laneObject.X > appWidth)
            {
                if (laneObject.ReadyToShow)
                {
                    laneObject.Show();
                }

                laneObject.X = -laneObject.Width;
            }
        }

        private static void moveLaneObjectLeft(GameObject laneObject, double appWidth)
        {
            laneObject.Move(Direction.Left);

            if (laneObject.X + laneObject.Width < 0)
            {
                if (laneObject.ReadyToShow)
                {
                    laneObject.Show();
                }

                laneObject.X = appWidth;
            }
        }

        /// <summary>
        /// Gets the lane objects.
        /// </summary>
        /// <returns></returns>
        public IReadOnlyList<GameObject> GetLaneObjects()
        {
            return this.LaneObjects.AsReadOnly();
        }

        /// <summary>
        /// Resets the speed.
        /// </summary>
        public virtual void ResetSpeed()
        {
            this.LaneObjects.ForEach(laneObject => laneObject.SetSpeed(this.initialSpeed, laneObject.SpeedY));
        }

        /// <summary>
        /// Stops the lane objects.
        /// </summary>
        public void StopLaneObjects()
        {
            this.LaneObjects.ForEach(laneObject => laneObject.SetSpeed(0, 0));
        }

        /// <summary>
        /// Adds the lane object.
        /// </summary>
        /// <param name="laneObject">The lane object.</param>
        public void AddLaneObject(GameObject laneObject)
        {
            this.LaneObjects.Add(laneObject);
        }

        /// <summary>
        /// Removes the lane object.
        /// </summary>
        /// <param name="laneObject">The lane object.</param>
        public void RemoveLaneObject(GameObject laneObject)
        {
            this.LaneObjects.Remove(laneObject);
        }

        #endregion
    }
}