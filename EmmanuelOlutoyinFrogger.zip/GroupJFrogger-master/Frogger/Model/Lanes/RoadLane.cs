﻿using Frogger.Model.Levels;

namespace Frogger.Model.Lanes
{
    /// <summary>
    /// Represents a road lane in the game.
    /// </summary>
    /// <seealso cref="Frogger.Model.Lanes.Lane" />
    public class RoadLane : Lane
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RoadLane"/> class.
        /// </summary>
        /// <param name="direction">The direction.</param>
        /// <param name="speed">The speed.</param>
        /// <param name="upperLeftYPosition">The upper left y position.</param>
        /// <param name="maxNumOfLaneObjects">The maximum number of lane objects.</param>
        /// <param name="laneObjectType">Type of the lane object.</param>
        public RoadLane(Direction direction, double speed, double upperLeftYPosition,
            int maxNumOfLaneObjects, LaneObjectType laneObjectType) : base(direction, speed, upperLeftYPosition,
            maxNumOfLaneObjects, laneObjectType)
        {
            Lanetype = LaneType.Road;
        }

        #endregion
    }
}