﻿namespace Frogger.Model.Lanes
{
    /// <summary>
    /// Define the different lane types
    /// </summary>
    public enum LaneType
    {
        /// <summary>
        /// The road lane
        /// </summary>
        Road,
        /// <summary>
        /// The river lane
        /// </summary>
        River,
        /// <summary>
        /// The home lane
        /// </summary>
        Home
    }
}