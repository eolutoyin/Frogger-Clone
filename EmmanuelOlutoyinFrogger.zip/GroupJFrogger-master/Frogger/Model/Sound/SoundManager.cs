﻿namespace Frogger.Model.Sound
{
    /// <summary>
    /// Manages sound effects within the game.
    /// </summary>
    public class SoundManager
    {
        #region Data members

        /// <summary>
        /// The sound factory
        /// </summary>
        private readonly SoundFactory soundFactory;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SoundManager"/> class.
        /// </summary>
        public SoundManager()
        {
            this.soundFactory = new SoundFactory();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Plays the sound.
        /// </summary>
        /// <param name="soundType">Type of the sound.</param>
        public void PlaySound(SoundType soundType)
        {
            this.soundFactory.CreateSound(soundType).Play();
        }

        #endregion
    }
}