﻿namespace Frogger.Model.Sound
{
    /// <summary>
    /// Enumerates the different types of sound effects used in the game.
    /// </summary>
    public enum SoundType
    {
        /// <summary>
        /// Sound effect for a player's death due to a collision with a vehicle.
        /// </summary>
        DeathViaCollisionWithVehicle,

        /// <summary>
        /// Sound effect for a player's death due to falling into water.
        /// </summary>
        DeathViaWater,

        /// <summary>
        /// Sound effect for a collision with a wall.
        /// </summary>
        CollisionWithWall,

        /// <summary>
        /// Sound effect when the game timer is running out.
        /// </summary>
        TimerRunningOut,

        /// <summary>
        /// Sound effect for reaching the home or destination point.
        /// </summary>
        PlayerAtHome,

        /// <summary>
        /// Sound effect for completing a level.
        /// </summary>
        LevelCompleted,

        /// <summary>
        /// Sound effect for acquiring a power-up.
        /// </summary>
        PowerUpAcquired,

        /// <summary>
        /// Sound effect for the game over scenario.
        /// </summary>
        GameOver
    }
}