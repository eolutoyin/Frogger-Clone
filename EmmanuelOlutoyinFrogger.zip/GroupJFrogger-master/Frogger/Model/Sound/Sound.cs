﻿using System;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Frogger.Settings;

namespace Frogger.Model.Sound
{
    /// <summary>
    /// Represents an audio file within the game
    /// </summary>
    public class Sound
    {
        #region Properties

        private string AudioFilePath { get; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Sound"/> class.
        /// </summary>
        /// <param name="audioFilePath">The audio file path.</param>
        public Sound(string audioFilePath)
        {
            this.AudioFilePath = audioFilePath;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Plays a sound instance.
        /// </summary>
        public async void Play()
        {
            var element = new MediaElement();
            var file = await StorageFile.GetFileFromApplicationUriAsync(new Uri("ms-appx:///" + this.AudioFilePath));
            var stream = await file.OpenAsync(FileAccessMode.Read);
            element.SetSource(stream, file.ContentType);
            element.Volume = 0.5;
            var duration = TimeSpan.FromSeconds(GameSettings.OfSecondsToPlayAudio);
            var timer = new DispatcherTimer
            {
                Interval = duration
            };
            timer.Tick += (s, e) =>
            {
                element.Stop();
                timer.Stop();
            };

            element.Play();
            timer.Start();
        }

        #endregion
    }
}