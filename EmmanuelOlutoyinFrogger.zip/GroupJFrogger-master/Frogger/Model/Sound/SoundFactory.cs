﻿using System;

namespace Frogger.Model.Sound
{
    /// <summary>
    /// Responsible for creating sound objects in the game.
    /// </summary>
    public class SoundFactory
    {
        #region Methods

        /// <summary>
        /// Creates the sound.
        /// </summary>
        /// <param name="soundType">Type of the sound.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentException">Invalid sound type</exception>
        public Sound CreateSound(SoundType soundType)
        {
            switch (soundType)
            {
                case SoundType.DeathViaCollisionWithVehicle:
                    return new Sound("..\\..\\Assets\\SoundEffectsAudioFiles\\DeathViaVehicle.wav");
                case SoundType.DeathViaWater:
                    return new Sound("..\\..\\Assets\\SoundEffectsAudioFiles\\DeathViaWater.wav");
                case SoundType.CollisionWithWall:
                    return new Sound("..\\..\\Assets\\SoundEffectsAudioFiles\\CollisionWithWall.wav");
                case SoundType.TimerRunningOut:
                    return new Sound("..\\..\\Assets\\SoundEffectsAudioFiles\\TimerRunningOut.wav");
                case SoundType.PlayerAtHome:
                    return new Sound("..\\..\\Assets\\SoundEffectsAudioFiles\\PlayerAtHome.wav");
                case SoundType.LevelCompleted:
                    return new Sound("..\\..\\Assets\\SoundEffectsAudioFiles\\LevelCompleted.wav");
                case SoundType.PowerUpAcquired:
                    return new Sound("..\\..\\Assets\\SoundEffectsAudioFiles\\PowerUpAcquired.wav");
                case SoundType.GameOver:
                    return new Sound("..\\..\\Assets\\SoundEffectsAudioFiles\\GameOver.wav");
                default:
                    throw new ArgumentException("Invalid sound type");
            }
        }

        #endregion
    }
}