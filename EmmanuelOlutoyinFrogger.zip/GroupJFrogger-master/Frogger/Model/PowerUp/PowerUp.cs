﻿using Frogger.Model.GameObjects;
using Frogger.Model.Levels;

namespace Frogger.Model.PowerUp
{
    /// <summary>
    /// Represents a power-up in the game, inheriting from GameObject.
    /// </summary>
    /// <seealso cref="Frogger.Model.GameObjects.GameObject" />
    public class PowerUp : GameObject
    {
        #region Properties

        /// <summary>
        /// Gets or sets the type of the power up.
        /// </summary>
        /// <value>
        /// The type of the power up.
        /// </value>
        public PowerUpType PowerUpType { get; set; }


        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PowerUp"/> class.
        /// </summary>
        /// <param name="powerUpType">Type of the power up.</param>
        /// <param name="laneObjectType">Type of the lane object.</param>
        public PowerUp(PowerUpType powerUpType, LaneObjectType laneObjectType)
        {
            this.PowerUpType = powerUpType;
            LaneObjectType = laneObjectType;
        }

        #endregion
    }
}