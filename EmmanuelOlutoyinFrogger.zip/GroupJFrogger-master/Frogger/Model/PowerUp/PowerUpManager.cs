﻿using System;
using System.Collections.Generic;
using System.Linq;
using Frogger.Model.Lanes;
using Frogger.Settings;

namespace Frogger.Model.PowerUp
{
    /// <summary>
    /// Manages the creation, positioning, and interaction of power-ups within the game
    /// </summary>
    public class PowerUpManager
    {
        #region Data members

        /// <summary>
        /// The power up factory
        /// </summary>
        private readonly PowerUpFactory powerUpFactory;
        /// <summary>
        /// The background width
        /// </summary>
        private readonly double backgroundWidth;
        /// <summary>
        /// The active power ups
        /// </summary>
        private readonly IList<PowerUp> activePowerUps = new List<PowerUp>();

        #endregion

        #region Properties

        /// <summary>
        /// Gets the active power ups.
        /// </summary>
        /// <value>
        /// The active power ups.
        /// </value>
        public IEnumerable<PowerUp> ActivePowerUps => this.activePowerUps.AsEnumerable();

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PowerUpManager"/> class.
        /// </summary>
        /// <param name="backgroundWidth">Width of the background.</param>
        /// <exception cref="System.ArgumentOutOfRangeException">backgroundWidth</exception>
        public PowerUpManager(double backgroundWidth)
        {

            if (backgroundWidth <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(backgroundWidth));
            }

            this.backgroundWidth = backgroundWidth;
            this.powerUpFactory = new PowerUpFactory();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Generates the power up.
        /// </summary>
        /// <param name="powerUpType">Type of the power up.</param>
        /// <returns></returns>
        public PowerUp GeneratePowerUp(PowerUpType powerUpType)
        {
            return this.powerUpFactory.CreatePowerUp(powerUpType);
        }

        /// <summary>
        /// Adds the power up.
        /// </summary>
        /// <param name="powerUp">The power up.</param>
        public void AddPowerUp(PowerUp powerUp)
        {
            this.activePowerUps.Add(powerUp);
        }

        /// <summary>
        /// Removes the power up.
        /// </summary>
        /// <param name="powerUp">The power up.</param>
        public void RemovePowerUp(PowerUp powerUp)
        {
            this.activePowerUps.Remove(powerUp);
        }

        /// <summary>
        /// Sets the power up position.
        /// </summary>
        /// <param name="powerUp">The power up.</param>
        /// <param name="roadLane">The road lane.</param>
        public void SetPowerUpPosition(PowerUp powerUp, Lane roadLane)
        {
            var random = new Random();
            var xPos = random.Next(0, (int)(this.backgroundWidth - powerUp.Sprite.Width));
            var yPos = roadLane.UpperLeftYPosition;

            powerUp.X = xPos;
            powerUp.Y = yPos;
        }

        /// <summary>
        /// Handles the power up collision.
        /// </summary>
        /// <param name="powerUp">The power up.</param>
        /// <param name="lives">The lives.</param>
        /// <param name="onExtraLife">The on extra life.</param>
        /// <param name="onExtraTime">The on extra time.</param>
        /// <exception cref="System.InvalidOperationException">Unknown PowerUpType</exception>
        public void HandlePowerUpCollision(PowerUp powerUp, ref int lives, Action<int> onExtraLife,
            Action<int> onExtraTime)
        {
            switch (powerUp.PowerUpType)
            {
                case PowerUpType.ExtraTime:
                    onExtraTime?.Invoke(GameSettings.AdditionalTime);
                    break;
                case PowerUpType.ExtraLife:
                    lives += GameSettings.AdditionalLife;
                    onExtraLife?.Invoke(lives);
                    break;
                default:
                    throw new InvalidOperationException("Unknown PowerUpType");
            }

            this.RemovePowerUp(powerUp);
        }

        #endregion
    }
}