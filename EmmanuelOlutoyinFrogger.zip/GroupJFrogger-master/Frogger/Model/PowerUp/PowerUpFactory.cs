﻿using System;
using Frogger.Model.Levels;
using Frogger.View.Sprites;
using Frogger.View.Sprites.PowerUpSprites;

namespace Frogger.Model.PowerUp
{
    /// <summary>
    /// Responsible for creating power-up objects in the game.
    /// </summary>
    public class PowerUpFactory
    {
        #region Methods

        /// <summary>
        /// Creates the power up.
        /// </summary>
        /// <param name="powerUpType">Type of the power up.</param>
        /// <returns></returns>
        public PowerUp CreatePowerUp(PowerUpType powerUpType)
        {
            var powerUpSprite = getSpriteForPowerUpType(powerUpType);
            var newPowerUp = new PowerUp(powerUpType, LaneObjectType.PowerUp)
            {
                Sprite = powerUpSprite
            };

            return newPowerUp;
        }

        private static BaseSprite getSpriteForPowerUpType(PowerUpType powerUpType)
        {
            switch (powerUpType)
            {
                case PowerUpType.ExtraLife:
                    return new ExtraLifeSprite();

                case PowerUpType.ExtraTime:
                    return new ExtraTimeSprite();

                default:
                    throw new InvalidOperationException("Unsupported PowerUpType");
            }
        }

        #endregion
    }
}