﻿namespace Frogger.Model.PowerUp
{
    /// <summary>
    /// Defines the types of power-ups available in the game.
    /// </summary>
    public enum PowerUpType
    {
        /// <summary>
        /// Represents a power-up that grants the player an extra life.
        /// </summary>
        ExtraLife,
        /// <summary>
        /// Represents a power-up that grants the player additional time.
        /// </summary>
        ExtraTime
    }
}