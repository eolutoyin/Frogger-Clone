﻿using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml;

namespace Frogger.Helpers
{
    /// <summary>
    /// Provides helper methods for navigation within a Universal Windows Platform application.
    /// </summary>
    public class NavigationHelper
    {
        /// <summary>
        /// Finds the frame.
        /// </summary>
        /// <param name="start">The start.</param>
        /// <returns></returns>
        public static Frame FindFrame(DependencyObject start)
        {
            var current = start;
            while (current != null)
            {
                if (current is Frame frame)
                {
                    return frame;
                }
                current = VisualTreeHelper.GetParent(current);
            }
            return null;
        }
    }
}