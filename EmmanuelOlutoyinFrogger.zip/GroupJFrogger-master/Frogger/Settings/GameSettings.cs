﻿using System;

namespace Frogger.Settings
{
    /// <summary>
    /// Contains constants and settings that define the game's behavior and mechanics
    /// </summary>
    public class GameSettings
    {
        #region Data members

        /// <summary>
        /// The number of lives to lose
        /// </summary>
        public const int OfLivesToLose = 0;
        /// <summary>
        /// The number of starting lives
        /// </summary>
        public const int StartingLives = 4;
        /// <summary>
        /// The death frame duration in milliseconds
        /// </summary>
        public const int DeathFrameDurationInMilliseconds = 1000;
        /// <summary>
        /// The frog movement frame duration in milliseconds
        /// </summary>
        public const int FrogMovementFrameDurationInMilliseconds = 5;
        /// <summary>
        /// The of seconds for timer
        /// </summary>
        public const int OfSecondsForTimer = 50;
        /// <summary>
        /// The of homes for lose
        /// </summary>
        public const int OfHomesForLose = 0;
        /// <summary>
        /// The of homes to win the level
        /// </summary>
        public const int OfHomes = 5;
        /// <summary>
        /// The of seconds between additional cars
        /// </summary>
        public const int OfSecondsBetweenAdditionalCars = 5;
        /// <summary>
        /// The pixel collision tollerace
        /// </summary>
        public const int PixelCollisionTollerace = 0;
        /// <summary>
        /// The obstacle height in pixels
        /// </summary>
        public const int ObstacleHeightInPixels = 50;
        /// <summary>
        /// The additional time
        /// </summary>
        public const int AdditionalTime = 5;
        /// <summary>
        /// The additional life
        /// </summary>
        public const int AdditionalLife = 1;
        /// <summary>
        /// The of seconds to play audio
        /// </summary>
        public const int OfSecondsToPlayAudio = 5;
        /// <summary>
        /// The game timer interval
        /// </summary>
        public static readonly TimeSpan GameTimerInterval = TimeSpan.FromMilliseconds(15);
        /// <summary>
        /// The life timer interval
        /// </summary>
        public static readonly TimeSpan LifeTimerInterval = TimeSpan.FromSeconds(1);
        /// <summary>
        /// The power up timer interval
        /// </summary>
        public static readonly TimeSpan PowerUpTimerInterval = TimeSpan.FromSeconds(5);
        /// <summary>
        /// The minimum speed of lane object
        /// </summary>
        public const double MinimumSpeedOfLaneObject = 1.0;
        /// <summary>
        /// The tolerance for comparing
        /// </summary>
        public const double ToleranceForComparing = 1;
        /// <summary>
        /// The score for starting
        /// </summary>
        public const int StartingScore = 0;

        #endregion
    }
}